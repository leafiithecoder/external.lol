﻿using ExitGames.Client.Photon;
using GorillaLocomotion;
using Photon.Pun;
using Photon.Realtime;
using externallol.Classes;
using externallol.Classes.Network;
using externallol.Menu;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;
using static externallol.Menu.Buttons;
using static externallol.Menu.Main;

namespace externallol.Mods;

public abstract class Movement
{

    private static GameObject platl;
    private static GameObject platr;


    public static bool previousTeleportTrigger;
    public static void Fly()
    {
        if (!ControllerInputPoller.instance.rightControllerPrimaryButton)
            return;

        GTPlayer.Instance.transform.position += GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime * Settings.Movement.flySpeed;
        GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
    }

    public static void TriggerFly()
    {
        if (rightTriggerPressed)
        {
            GTPlayer.Instance.transform.position += GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime * Settings.Movement.flySpeed;
            GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
        }
    }

    public static void HandFly()
    {
        if (rightPrimary)
        {
            GTPlayer.Instance.transform.position += TrueRightHand().forward * (Time.deltaTime * Settings.Movement.flySpeed);
            GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
        }
    }

    public static bool noclip;
    public static void NoclipFly()
    {
        if (rightPrimary)
        {
            GTPlayer.Instance.transform.position += GorillaTagger.Instance.headCollider.transform.forward * (Time.deltaTime * Settings.Movement.flySpeed);
            GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
            if (!noclip)
            {
                noclip = true;
                UpdateClipColliders(false);
            }
        }
        else
        {
            if (noclip)
            {
                noclip = false;
                UpdateClipColliders(true);
            }
        }
    }

    public static void Platforms()
    {
        bool leftActive;
        bool rightActive;

        bool nsp = GetIndex("Non-Sticky Platforms").enabled;

        if (triggerPlatforms)
        {
            leftActive = leftTriggerPressed;
            rightActive = rightTriggerPressed;
        }
        else
        {
            leftActive = ControllerInputPoller.instance.leftGrab;
            rightActive = ControllerInputPoller.instance.rightGrab;
        }

        if (leftActive)
        {
            if (platl == null)
            {
                platl = GameObject.CreatePrimitive(
                    Settings.Movement.platformShape
                );

                platl.transform.localScale =
                    Settings.Movement.PlatformShapeScale;

                platl.transform.position =
                    TrueLeftHand().position +
                    TrueLeftHand().right * 0.05f;

                platl.transform.rotation =
                    TrueLeftHand().rotation;

                if (!nsp)
                    FixStickyColliders(platl);

                ColorChanger colorChanger =
                    platl.AddComponent<ColorChanger>();

                colorChanger.colors =
                    Menu.Settings.backgroundColor;
            }
        }
        else if (platl != null)
        {
            Object.Destroy(platl);
            platl = null;
        }

        if (rightActive)
        {
            if (platr == null)
            {
                platr = GameObject.CreatePrimitive(
                    Settings.Movement.platformShape
                );

                platr.transform.localScale =
                    Settings.Movement.PlatformShapeScale;

                platr.transform.position =
                    TrueRightHand().position -
                    TrueRightHand().right * 0.05f;

                platr.transform.rotation =
                    TrueRightHand().rotation;

                if (!nsp)
                    FixStickyColliders(platr);

                ColorChanger colorChanger =
                    platr.AddComponent<ColorChanger>();

                colorChanger.colors =
                    Menu.Settings.backgroundColor;
            }
        }
        else if (platr != null)
        {
            Object.Destroy(platr);
            platr = null;
        }
    }

    private static readonly Dictionary<bool, List<GameObject>> frozonicPlatforms = new Dictionary<bool, List<GameObject>>();
    private static readonly Dictionary<bool, int> platformIndex = new Dictionary<bool, int>();
    public static void HandleFrozone(bool left)
    {
        bool grip = left ? leftGrab : rightGrab;

        frozonicPlatforms.TryGetValue(left, out List<GameObject> frozonicPlatformList);
        if (frozonicPlatformList == null)
        {
            frozonicPlatformList = new List<GameObject>();
            frozonicPlatforms.Add(left, frozonicPlatformList);
        }

        platformIndex.TryGetValue(left, out int index);

        if (grip)
        {
            GameObject platform;
            if (frozonicPlatformList.Count >= 72)
                platform = frozonicPlatformList[index];
            else
            {
                platform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                platform.GetComponent<Renderer>().material.color = Menu.Settings.backgroundColor.GetCurrentColor();
                platform.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f) * (1f);
                platform.AddComponent<GorillaSurfaceOverride>().overrideIndex = 61;
                frozonicPlatformList.Add(platform);
            }

            var (position, rotation, _, _, right) = left ? TrueLeftHand() : TrueRightHand();

            platform.transform.position = position + (right * ((left ? 1f : -1f) * ((0.025f + platform.transform.localScale.x / 2f) * (1f))));
            platform.transform.rotation = rotation;

            index = (index + 1) % 72;
        }

        platformIndex[left] = index;

        if (!grip && frozonicPlatformList.Count > 0)
        {
            int platformIndex = frozonicPlatformList.Count - 1;

            Object.Destroy(frozonicPlatformList[platformIndex]);
            frozonicPlatformList.RemoveAt(platformIndex);
        }
    }

    public static void Frozone()
    {
        HandleFrozone(true);
        HandleFrozone(false);

        GorillaTagger.Instance.bodyCollider.enabled = !(leftGrab || rightGrab);
    }

    public static void PlatformGun()
    {
        if (GetGunInput(false))
        {
            var GunData = RenderGun();
            GameObject NewPointer = GunData.NewPointer;

            if (GetGunInput(true))
            {
                GameObject platform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                Object.Destroy(platform.GetComponent<BoxCollider>());
                platform.GetComponent<Renderer>().material.color = Menu.Settings.backgroundColor.GetCurrentColor();
                platform.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                platform.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
                platform.transform.position = NewPointer.transform.position;
                platform.transform.rotation = Quaternion.Euler(Random.Range(0, 360), Random.Range(0, 360), Random.Range(0, 360));
                Object.Destroy(platform, 1f);
            }
        }
    }

    // deprecated, we use networked object now
    public static void NetworkedPlats()
    {
        bool leftActive;
        bool rightActive;

        if (triggerPlatforms)
        {
            leftActive = Mouse.current.leftButton.isPressed;
            rightActive = Mouse.current.rightButton.isPressed;
        }
        else
        {
            leftActive = ControllerInputPoller.instance.leftGrab;
            rightActive = ControllerInputPoller.instance.rightGrab;
        }

        if (leftActive)
        {
            if (platl == null)
            {
                platl = GameObject.CreatePrimitive(
                    PrimitiveType.Cube
                );

                platl.transform.localScale =
                    new Vector3(0.025f, 0.3f, 0.4f);

                platl.transform.position =
                    TrueLeftHand().position +
                    TrueLeftHand().right * 0.05f;

                platl.transform.rotation =
                    TrueLeftHand().rotation;

                FixStickyColliders(platl);

                ColorChanger colorChanger =
                    platl.AddComponent<ColorChanger>();

                colorChanger.colors =
                    Menu.Settings.backgroundColor;

                External.Send(
                    "platform",
                    ReceiverGroup.Others,
                    "left",
                    platl.transform.position,
                    platl.transform.localScale,
                    platl.transform.eulerAngles
                );
            }
        }
        else if (platl != null)
        {
            External.Send(
                "platformDestroy",
                ReceiverGroup.Others,
                "left"
            );

            Object.Destroy(platl);
            platl = null;
        }

        if (rightActive)
        {
            if (platr == null)
            {
                platr = GameObject.CreatePrimitive(
                    PrimitiveType.Cube
                );

                platr.transform.localScale =
                    new Vector3(0.025f, 0.3f, 0.4f);

                platr.transform.position =
                    TrueRightHand().position -
                    TrueRightHand().right * 0.05f;

                platr.transform.rotation =
                    TrueRightHand().rotation;

                FixStickyColliders(platr);

                ColorChanger colorChanger =
                    platr.AddComponent<ColorChanger>();

                colorChanger.colors =
                    Menu.Settings.backgroundColor;

                External.Send(
                    "platform",
                    ReceiverGroup.Others,
                    "right",
                    platr.transform.position,
                    platr.transform.localScale,
                    platr.transform.eulerAngles
                );
            }
        }
        else if (platr != null)
        {
            External.Send(
                "platformDestroy",
                ReceiverGroup.Others,
                "right"
            );

            Object.Destroy(platr);
            platr = null;
        }
    }

    public static void TeleportGun()
    {
        if (GetGunInput(false))
        {
            var GunData = RenderGun();
            GameObject NewPointer = GunData.NewPointer;

            if (GetGunInput(true) && !previousTeleportTrigger)
            {
                closePosition = Vector3.zero;
                TeleportPlayer(NewPointer.transform.position + Vector3.up);
                GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
            }

            previousTeleportTrigger = GetGunInput(true);
        }
    }


    public static void SpeedBoost()
    {
        bool hasControl = gripSpeedBoost || triggerSpeedBoost;

        if (!hasControl)
        {
            GTPlayer.Instance.maxJumpSpeed = Settings.Movement.speedAmount;
            GTPlayer.Instance.jumpMultiplier = Settings.Movement.speedMultiplier;
            return;
        }

        if (gripSpeedBoost && (rightGrab || leftGrab))
        {
            GTPlayer.Instance.maxJumpSpeed = Settings.Movement.speedAmount;
            GTPlayer.Instance.jumpMultiplier = Settings.Movement.speedMultiplier;
            return;
        }

        if (triggerSpeedBoost && (rightTriggerPressed || leftTriggerPressed))
        {
            GTPlayer.Instance.maxJumpSpeed = Settings.Movement.speedAmount;
            GTPlayer.Instance.jumpMultiplier = Settings.Movement.speedMultiplier;
            return;
        }
    }
    public static void UpdateClipColliders(bool enabled)
    {
        foreach (MeshCollider v in Resources.FindObjectsOfTypeAll<MeshCollider>())
            v.enabled = enabled;
    }
    public static void Noclip()
    {
        bool gripNoclip = GetIndex("Grip Noclip").enabled;
        if (gripNoclip ? rightGrab : rightTrigger > 0.5f || GetIndex("Constant Noclip").enabled)
        {
            if (!noclip)
            {
                noclip = true;
                UpdateClipColliders(false);
            } 
        }
        else
        {
            if (noclip)
            {
                noclip = false;
                UpdateClipColliders(true);
            }
        }
    }
    public static void EnableSteamLongArms() =>
        GTPlayer.Instance.transform.localScale = Vector3.one * VRRig.LocalRig.NativeScale * Settings.Movement.armLength;
    public static void DisableSteamLongArms() =>
        GTPlayer.Instance.transform.localScale = Vector3.one * VRRig.LocalRig.NativeScale;

    public static void StickLongArms()
    {
        GTPlayer.Instance.GetControllerTransform(true).transform.position = GorillaTagger.Instance.leftHandTransform.position + GorillaTagger.Instance.leftHandTransform.forward * ((Settings.Movement.armLength - 0.917f) * GTPlayer.Instance.scale);
        GTPlayer.Instance.GetControllerTransform(false).transform.position = GorillaTagger.Instance.rightHandTransform.position + GorillaTagger.Instance.rightHandTransform.forward * ((Settings.Movement.armLength - 0.917f) * GTPlayer.Instance.scale);
    }

    public static void BarkFly()
    {
        Vector3 inputDirection = new Vector3(leftJoystick.x, rightJoystick.y, leftJoystick.y);

        Vector3 playerForward = GTPlayer.Instance.bodyCollider.transform.forward.X_Z();
        Vector3 playerRight = GTPlayer.Instance.bodyCollider.transform.right.X_Z();

        Vector3 velocity = inputDirection.x * playerRight + inputDirection.y * Vector3.up + inputDirection.z * playerForward;
        velocity *= Settings.Movement.flySpeed;
        GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.Lerp(GorillaTagger.Instance.rigidbody.linearVelocity, velocity, 0.12875f);

        ZeroGravity();
    }

    public static GameObject stickpart;
    public static void StickyHands()
    {
        if (stickpart == null)
        {
            stickpart = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            FixStickyColliders(stickpart);
            stickpart.transform.localScale = new Vector3(0.15f, 0.15f, 0.15f);
            stickpart.GetComponent<Renderer>().enabled = false;
        }
        if (GTPlayer.Instance.IsHandTouching(true))
            stickpart.transform.position = TrueLeftHand().position;

        if (GTPlayer.Instance.IsHandTouching(false))
            stickpart.transform.position = TrueRightHand().position;

        if (GTPlayer.Instance.IsHandTouching(true) && GTPlayer.Instance.IsHandTouching(false))
            stickpart.transform.position = Vector3.zero;
    }
    public static void DisableStickyHands()
    {
        if (stickpart != null)
        {
            Object.Destroy(stickpart);
            stickpart = null;
        }
    }
    public static float oldSlide;
    public static void EnableSlideControl()
    {
        oldSlide = GTPlayer.Instance.slideControl;
        GTPlayer.Instance.slideControl = 1f;
        GTPlayer.Instance.slideFactor = 0f;
    }
    public static void DisableSlideControl() =>
        GTPlayer.Instance.slideControl = oldSlide;

    
    public static void LowGravity() =>
        GorillaTagger.Instance.rigidbody.AddForce(Vector3.up * 6.66f, ForceMode.Acceleration);
    public static void ZeroGravity() =>
        GorillaTagger.Instance.rigidbody.AddForce(-Physics.gravity, ForceMode.Acceleration);
    public static void HighGravity() =>
        GorillaTagger.Instance.rigidbody.AddForce(Vector3.down * 7.77f, ForceMode.Acceleration);
    public static void UpAndDown()
    {
        if (rightTrigger > 0.5f || rightGrab)
            ZeroGravity();

        if (rightTrigger > 0.5f)
            GorillaTagger.Instance.rigidbody.linearVelocity += Vector3.up * (Time.deltaTime * Settings.Movement.flySpeed * 3f);

        if (rightGrab)
            GorillaTagger.Instance.rigidbody.linearVelocity += Vector3.up * (Time.deltaTime * Settings.Movement.flySpeed * -3f);
    }
    public static void LeftAndRight()
    {
        if (rightTrigger > 0.5f || rightGrab)
            ZeroGravity();

        if (rightTrigger > 0.5f)
            GorillaTagger.Instance.rigidbody.linearVelocity += GorillaTagger.Instance.bodyCollider.transform.right * (Time.deltaTime * Settings.Movement.flySpeed * -3f);

        if (rightGrab)
            GorillaTagger.Instance.rigidbody.linearVelocity += GorillaTagger.Instance.bodyCollider.transform.right * (Time.deltaTime * Settings.Movement.flySpeed * 3f);
    }
    public static void ForwardsAndBackwards()
    {
        if (rightTrigger > 0.5f || rightGrab)
            ZeroGravity();

        if (rightTrigger > 0.5f)
            GorillaTagger.Instance.rigidbody.linearVelocity += GorillaTagger.Instance.bodyCollider.transform.forward * (Time.deltaTime * Settings.Movement.flySpeed * 3f);

        if (rightGrab)
            GorillaTagger.Instance.rigidbody.linearVelocity += GorillaTagger.Instance.bodyCollider.transform.forward * (Time.deltaTime * Settings.Movement.flySpeed * -3f);
    }
    public static void ForceTagFreeze() =>
        GTPlayer.Instance.disableMovement = true;
    public static void NoTagFreeze() =>
        GTPlayer.Instance.disableMovement = false;

    public static float startX = -1f;
    public static float startY = -1f;

    public static float subThingy;
    public static float subThingyZ;

    public static Vector3 lastPosition = Vector3.zero;

    public static void EnableWASDFly()
    {
        lastPosition = GorillaTagger.Instance.rigidbody.transform.position;

        if (XRSettings.isDeviceActive && Time.time < timeMenuStarted + 1f)
            Toggle("WASD Fly");
    }

    public static void WASDFly()
    {
        if (Keyboard.current == null || Mouse.current == null)
            return;

        ZeroGravity();

        bool W = Keyboard.current.wKey.isPressed;
        bool A = Keyboard.current.aKey.isPressed;
        bool S = Keyboard.current.sKey.isPressed;
        bool D = Keyboard.current.dKey.isPressed;
        bool Space = Keyboard.current.spaceKey.isPressed;
        bool Ctrl = Keyboard.current.leftCtrlKey.isPressed;
        bool Shift = Keyboard.current.leftShiftKey.isPressed;
        bool Alt = Keyboard.current.leftAltKey.isPressed;

        bool LeftArrow = Keyboard.current.leftArrowKey.isPressed;
        bool RightArrow = Keyboard.current.rightArrowKey.isPressed;
        bool UpArrow = Keyboard.current.upArrowKey.isPressed;
        bool DownArrow = Keyboard.current.downArrowKey.isPressed;

        if (!menu)
        {
            Transform parentTransform = GTPlayer.Instance.GetControllerTransform(false).parent;

            float turnSpeed = 250f;

            if (LeftArrow)
                parentTransform.eulerAngles += new Vector3(0f, -turnSpeed, 0f) * Time.deltaTime;

            if (RightArrow)
                parentTransform.eulerAngles += new Vector3(0f, turnSpeed, 0f) * Time.deltaTime;

            if (UpArrow)
                parentTransform.eulerAngles += new Vector3(-turnSpeed, 0f, 0f) * Time.deltaTime;

            if (DownArrow)
                parentTransform.eulerAngles += new Vector3(turnSpeed, 0f, 0f) * Time.deltaTime;

            if (Mouse.current.rightButton.isPressed)
            {
                Quaternion currentRotation = parentTransform.rotation;
                Vector3 euler = currentRotation.eulerAngles;

                if (startX < 0)
                {
                    startX = euler.y;
                    subThingy = Mouse.current.position.value.x / Screen.width;
                }

                if (startY < 0)
                {
                    startY = euler.x;
                    subThingyZ = Mouse.current.position.value.y / Screen.height;
                }

                float newX = startY - (Mouse.current.position.value.y / Screen.height - subThingyZ) * 360f * 1.33f;
                float newY = startX + (Mouse.current.position.value.x / Screen.width - subThingy) * 360f * 1.33f;

                newX = newX > 180f ? newX - 360f : newX;
                newX = Mathf.Clamp(newX, -90f, 90f);

                parentTransform.rotation = Quaternion.Euler(newX, newY, euler.z);
            }
            else
            {
                startX = -1f;
                startY = -1f;
            }

            float speed = Settings.Movement.flySpeed;

            if (Shift)
                speed *= 2f;
            else if (Alt)
                speed /= 2f;

            float yaw = parentTransform.eulerAngles.y;

            Vector3 forward = Quaternion.Euler(0f, yaw, 0f) * Vector3.forward;
            Vector3 right = Quaternion.Euler(0f, yaw, 0f) * Vector3.right;

            if (W)
                GorillaTagger.Instance.rigidbody.transform.position += forward * (Time.deltaTime * speed);

            if (S)
                GorillaTagger.Instance.rigidbody.transform.position -= forward * (Time.deltaTime * speed);

            if (A)
                GorillaTagger.Instance.rigidbody.transform.position -= right * (Time.deltaTime * speed);

            if (D)
                GorillaTagger.Instance.rigidbody.transform.position += right * (Time.deltaTime * speed);

            if (Space)
                GorillaTagger.Instance.rigidbody.transform.position += Vector3.up * (Time.deltaTime * speed);

            if (Ctrl)
                GorillaTagger.Instance.rigidbody.transform.position += Vector3.down * (Time.deltaTime * speed);

            VRRig.LocalRig.head.rigTarget.transform.rotation =
                GorillaTagger.Instance.headCollider.transform.rotation;
        }

        if (!W && !A && !S && !D && !Space && !Ctrl && lastPosition != Vector3.zero)
            GorillaTagger.Instance.rigidbody.transform.position = lastPosition;
        else
            lastPosition = GorillaTagger.Instance.rigidbody.transform.position;
    }
    private static Vector3 walkPos;
    private static Vector3 walkNormal;
    private static float wallWalkStrength = 7.81f;

    public static void WallWalk()
    {
        if (GTPlayer.Instance.IsHandTouching(true) || GTPlayer.Instance.IsHandTouching(false))
        {
            RaycastHit ray = GTPlayer.Instance.lastHitInfoHand;
            walkPos = ray.point;
            walkNormal = ray.normal;
        }

        bool wallWalkKey = rightGrab || leftGrab;

        if (walkPos != Vector3.zero && wallWalkKey)
        {
            GorillaTagger.Instance.rigidbody.AddForce(walkNormal * -wallWalkStrength, ForceMode.Acceleration);
            ZeroGravity();
        }
    }

    public static void LegitimateWallWalk()
    {
        float range = 0.2f;
        float power = -2f;
        bool wallWalkKey = rightGrab || leftGrab;

        if (wallWalkKey)
        {
            RaycastHit ray = GTPlayer.Instance.lastHitInfoHand;

            if (Physics.Raycast(TrueLeftHand().position, -ray.normal, out var Ray, range, GTPlayer.Instance.locomotionEnabledLayers))
                GorillaTagger.Instance.rigidbody.AddForce(Ray.normal * power, ForceMode.Acceleration);
        }

        if (wallWalkKey)
        {
            RaycastHit ray = GTPlayer.Instance.lastHitInfoHand;

            if (Physics.Raycast(TrueRightHand().position, -ray.normal, out var Ray, range, GTPlayer.Instance.locomotionEnabledLayers))
                GorillaTagger.Instance.rigidbody.AddForce(Ray.normal * power, ForceMode.Acceleration);
        }
    }
    public static void Airstrike()
    {
        if (GetGunInput(false))
        {
            var GunData = RenderGun();
            GameObject NewPointer = GunData.NewPointer;

            if (GetGunInput(true) && !previousTeleportTrigger)
            {
                GorillaTagger.Instance.rigidbody.linearVelocity = new Vector3(0f, -20f, 0f);
                TeleportPlayer(NewPointer.transform.position + new Vector3(0f, 30f, 0f));
                GorillaTagger.Instance.rigidbody.linearVelocity = new Vector3(0f, -20f, 0f);
            }

            previousTeleportTrigger = GetGunInput(true);
        }
    }

    public static GameObject CheckPoint;
    public static void Checkpoint()
    {
        if (rightGrab)
        {
            if (CheckPoint == null)
            {
                CheckPoint = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Object.Destroy(CheckPoint.GetComponent<SphereCollider>());
                CheckPoint.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
            }
            CheckPoint.transform.position = GorillaTagger.Instance.rightHandTransform.position;
        }
        if (CheckPoint != null)
        {
            if (rightPrimary)
            {
                CheckPoint.GetComponent<Renderer>().material.color = Color.white;
                TeleportPlayer(CheckPoint.transform.position);
                GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
            }
            else
                CheckPoint.GetComponent<Renderer>().material.color = Color.white;
        }
    }

    public static void DisableCheckpoint()
    {
        if (CheckPoint != null)
        {
            Object.Destroy(CheckPoint);
            CheckPoint = null;
        }
    }

    private static float pullPower = 0.1f;
    private static readonly Dictionary<bool, bool> previousTouchingGround = new Dictionary<bool, bool>();
    public static void ProcessPullHand(bool left)
    {
        if ((left ? !leftGrab : !rightGrab))
            return;

        bool touchingGround = GTPlayer.Instance.IsHandTouching(left);
        previousTouchingGround.TryGetValue(left, out bool wasTouchingGround);

        if (!touchingGround && wasTouchingGround)
        {
            Vector3 normal = GTPlayer.Instance.lastHitInfoHand.normal;
            Vector3 direction = GorillaTagger.Instance.rigidbody.linearVelocity.X_Z();
            GTPlayer.Instance.transform.position += (direction - normal * Vector3.Dot(direction, normal)).normalized * (direction.magnitude / GTPlayer.Instance.maxJumpSpeed * (pullPower * 5f)) * 1f;
        }

        previousTouchingGround[left] = touchingGround;
    }

    public static void PullMod()
    {
        if (!leftGrab && !rightGrab)
        {
            previousTouchingGround.Clear();
            return;
        }
        ProcessPullHand(false);
        ProcessPullHand(true);
    }
}