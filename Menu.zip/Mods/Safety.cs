﻿using BepInEx;
using ExitGames.Client.Photon;
using Photon.Pun;
using externallol.Classes;
using externallol.Extensions;
using externallol.Managers;
using externallol.Notifications;
using System;
using System.Linq;
using UnityEngine;
using static externallol.Classes.RigManager;
using static externallol.Menu.Main;
using static externallol.Extensions.VRRigExtensions;
using Photon.Realtime;

namespace externallol.Mods
{
    public class Safety
    {
        public static VRRig reportRig;
        public static float antiReportDelay;

        public static void AntiReport(Action<VRRig, Vector3> onReport)
        {
            if (NetworkSystem.Instance == null || !NetworkSystem.Instance.InRoom)
            {
                reportRig = null;
                return;
            }

            if (reportRig != null)
            {
                VRRig detectedRig = reportRig;
                reportRig = null;

                if (detectedRig.transform != null)
                    onReport?.Invoke(detectedRig, detectedRig.transform.position);

                return;
            }

            if (GorillaScoreboardTotalUpdater.allScoreboardLines == null)
                return;

            foreach (GorillaPlayerScoreboardLine line in GorillaScoreboardTotalUpdater.allScoreboardLines)
            {
                if (line == null || line.linePlayer != NetworkSystem.Instance.LocalPlayer)
                    continue;

                if (line.reportButton == null)
                    continue;

                Transform report = line.reportButton.transform;

                foreach (VRRig vrrig in VRRigCache.m_activeRigs)
                {
                    if (vrrig == null || vrrig.isLocal)
                        continue;

                    if (vrrig.rightHandTransform == null || vrrig.leftHandTransform == null)
                        continue;

                    float rightDistance = Vector3.Distance(
                        vrrig.rightHandTransform.position,
                        report.position
                    );

                    float leftDistance = Vector3.Distance(
                        vrrig.leftHandTransform.position,
                        report.position
                    );

                    if (rightDistance < 0.35f || leftDistance < 0.35f)
                    {
                        onReport?.Invoke(vrrig, report.position);
                        return;
                    }
                }
            }
        }

        public static void AntiReportDisconnect()
        {
            AntiReport((vrrig, position) =>
            {
                if (vrrig == null || vrrig.IsLocal())
                    return;

                if (Time.time <= antiReportDelay)
                    return;

                antiReportDelay = Time.time + 1f;

                string playerName = "Unknown Player";

                try
                {
                    playerName = GetPlayerFromVRRig(vrrig).NickName;
                }
                catch { }

                NotificationManager.SendNotification(
                    $"{ModInfoNotif("ANTI-REPORT")} {playerName} attempted to report you, you have been disconnected."
                );

                NetworkSystem.Instance.ReturnToSinglePlayer();
                RPCProtection();
            });
        }
        public static void NoFingerMovement()
        {
            ControllerInputPoller.instance.leftControllerGripFloat = 0f;
            ControllerInputPoller.instance.rightControllerGripFloat = 0f;
            ControllerInputPoller.instance.leftControllerIndexFloat = 0f;
            ControllerInputPoller.instance.rightControllerIndexFloat = 0f;
            ControllerInputPoller.instance.leftControllerPrimaryButton = false;
            ControllerInputPoller.instance.leftControllerSecondaryButton = false;
            ControllerInputPoller.instance.rightControllerPrimaryButton = false;
            ControllerInputPoller.instance.rightControllerSecondaryButton = false;
            ControllerInputPoller.instance.leftControllerPrimaryButtonTouch = false;
            ControllerInputPoller.instance.leftControllerSecondaryButtonTouch = false;
            ControllerInputPoller.instance.rightControllerPrimaryButtonTouch = false;
            ControllerInputPoller.instance.rightControllerSecondaryButtonTouch = false;
        }

        public static float flushCooldown;
        public static void FlushRPCs()
        {
            if (Time.time > flushCooldown)
            {
                Menu.Main.RPCProtection();
                flushCooldown = Time.time + 5f;
                return;
            }
            NotificationManager.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> You are not meant to spam Flush RPCs. Only call it once after you are done spamming RPCs.");
        }

        public static void AntiModerator()
        {
            foreach (var vrrig in VRRigExtensions.ActiveRigs.Where(vrrig => !vrrig.isOfflineVRRig && vrrig.Cosmetics().Contains("LBAAK") || vrrig.Cosmetics().Contains("LBAAD") || vrrig.Cosmetics().Contains("LMAPY")))
            {
                try
                {
                    VRRig plr = vrrig;
                    NetPlayer player = GetPlayerFromVRRig(plr);
                }
                catch { }
                NetworkSystem.Instance.ReturnToSinglePlayer();
                NotificationManager.SendNotification($"{ModInfoNotif("ANTI-MODERATOR")} {vrrig.GetName()} is a moderator, you have been disconnected.");
            }
        }

        public static void EventReceived_AntiOculusReport(EventData data)
        {
            try
            {
                if (data.Code == PunEvent.RPC)
                {
                    var sender = PhotonNetwork.NetworkingClient.CurrentRoom.GetPlayer(data.Sender);
                    if (sender.IsLocal)
                        return;

                    string rpcName = PhotonNetwork.PhotonServerSettings.RpcList[int.Parse(((Hashtable)data.CustomData)[5].ToString())];
                    object[] args = (object[])((Hashtable)data.CustomData)[4];
                    if (rpcName == "RPC_PlayHandTap" && (int)args[0] == 67)
                    {
                        VRRig target = GetVRRigFromPlayer(sender);
                        if (Vector3.Distance(target.leftHandTransform.position, target.rightHandTransform.position) < 0.1f)
                            AntiReportFRT(PhotonNetwork.NetworkingClient.CurrentRoom.GetPlayer(data.Sender));
                    }
                }
            }
            catch { }
        }

        public static void EnableAntiOculusReport() =>
            PhotonNetwork.NetworkingClient.EventReceived += EventReceived_AntiOculusReport;

        public static void DisableAntiOculusReport() =>
            PhotonNetwork.NetworkingClient.EventReceived -= EventReceived_AntiOculusReport;

        public static void VIMAntiReport(bool block)
        {
            if (!VRRig.LocalRig.IsVIMSubscriber())
            {
                NotificationManager.SendNotification($"{warning} You are not a VIM subscriber, so this mod will not function.");
                return;
            }
            AntiReport((vrrig, position) =>
            {
                if (AdminManager.admins.Contains(vrrig.GetPlayer().UserId))
                {
                    return;
                }

                if (block)
                {
                    RoomControls.KickAndBlockPlayer(vrrig.GetPlayer().ActorNumber);
                }

                else
                {
                    RoomControls.KickPlayer(vrrig.GetPlayer().ActorNumber);
                }

                if (!(Time.time > antiReportDelay)) return;
                antiReportDelay = Time.time + 1f;
                NotificationManager.SendNotification($"{ModInfoNotif("ANTI-REPORT")} " + GetPlayerFromVRRig(vrrig).NickName + " attempted to report you, they have been kicked.");
                reportRig = null;
            });
        }

        public static void AntiReportNotify()
        {
            AntiReport((vrrig, position) =>
            {
                if (AdminManager.admins.Contains(vrrig.GetPlayer().UserId))
                {
                    return;
                }

                if (!(Time.time > antiReportDelay)) return;
                antiReportDelay = Time.time + 1f;
                NotificationManager.SendNotification($"{ModInfoNotif("ANTI-REPORT")} " + GetPlayerFromVRRig(vrrig).NickName + " is attempting to report you.");
                reportRig = null;
            });
        }

        public static void AntiReportFRT(Photon.Realtime.Player subject)
        {
            if (subject.IsLocal)
                return;

            reportRig = subject.VRRig();
        }

        public static void BreakModCheckerV2()
        {
            string prop = "H\nW\nY\nZ\nE\nO\nN\nT\nO\nP\n\nH\nW\nY\nZ\nE\nO\nN\nT\nO\nP\n\nH\nW\nY\nZ\nE\nO\nN\nT\nO\nP\n\nH\nW\nY\nZ\nE\nO\nN\nT\nO\nP\n\nH\nW\nY\nZ\nE\nO\nN\nT\nO\nP\n\n";
            if (!GorillaTagger.Instance.myVRRig.GetView.Controller.CustomProperties.ContainsKey(prop))
            {
                Hashtable hash = new Hashtable();
                hash.Add("hzye", prop);
                GorillaTagger.Instance.myVRRig.GetView.Controller.SetCustomProperties(hash);
            }
        }
    }
}