using BepInEx;
using ExitGames.Client.Photon;
using GorillaLocomotion;
using GorillaNetworking;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using externallol.Classes;
using externallol.Managers;
using externallol.Notifications;
using externallol.Tools;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using UnityEngine.XR;
using CommonUsages = UnityEngine.XR.CommonUsages;
using Valve.VR;
using static externallol.Menu.Buttons;
using static externallol.Menu.Settings;
using Button = externallol.Classes.Button;
using Random = UnityEngine.Random;
using static externallol.Tools.Utilities;
using externallol.Classes.Network;

namespace externallol.Menu;

[HarmonyPatch(typeof(GTPlayer), nameof(GTPlayer.LateUpdate))]
public class Main : MonoBehaviour
{
    /* 
     * 0
     * 1
     * 2
     */

    public static void OnLaunch()
    {
        // Room
        GameObject roomObject = new GameObject("room_mods_node");
        roomObject.AddComponent<Mods.Room>();
        ServerSyncPos = VRRig.LocalRig?.transform.position ?? ServerSyncPos;
        IsSteam = PlayFabAuthenticator.instance.platform;
        Init();
    }

    // Fields
    public static bool IsSteam = true;

    // Floats
    private const  float TextRenderScale   = 0.001f;
    private const  float TextSurfaceOffset = 0.0035f;
    public static float timeMenuStarted = -1f;
    public static float leftTrigger;
    public static float rightTrigger;

    // Bools
    public static bool gunLocked;
    public static bool leftTriggerPressed;
    public static bool rightTriggerPressed;
    public static bool gripSpeedBoost;
    public static bool triggerSpeedBoost;
    public static bool triggerPlatforms;
    public static bool nonStickyPlatforms;
    public static bool constantNoclip;
    public static bool gripNoclip;
    public static bool leftPrimary;
    public static bool leftSecondary;
    public static bool rightPrimary;
    public static bool rightSecondary;
    public static bool leftGrab;
    public static bool rightGrab;
    public static bool HasLoaded;
    public static bool susPC;
    private static bool searchUsingDesktopKeyboard;
    private static bool menuButtonWasPressed;
    private static bool menuToggledOpen;
    private static bool menuClosing;
    private static bool menuShouldDropOnClose;
    private static bool searchKeyboardFollowing;
    public static bool showLocalAdminIcon;
    public static bool showSimpleVersion;
    public static bool ghostException;

    // Strings
    public static string CosmeticsOwned;
    public static string success = "<color=grey>[</color><color=green>SUCCESS</color><color=grey>]</color>";
    public static string fail = "<color=grey>[</color><color=red>FAIL</color><color=grey>]</color>";
    public static string warning = "<color=grey>[</color><color=red>WARNING</color><color=grey>]</color>";
    public static string info = "<color=grey>[</color><color=purple>INFO</color><color=grey>]</color>";
    private static string searchQuery = string.Empty;
    public static HashSet<string> menuUsers = new(); // only for people in the room

    // moved admin data to json

    // Integers
    private static int? noInvisLayerMask;
    public static int pageNumber;

    // Vector3/2s
    public static Vector3 closePosition;
    public static Vector3 ServerSyncPos;
    public static Vector3 ServerSyncLeftHandPos;
    public static Vector3 ServerSyncRightHandPos;
    public static Vector3 ServerPos;
    public static Vector3 ServerLeftHandPos;
    public static Vector3 ServerRightHandPos;
    private static readonly Vector3 MenuScale = new(
        0.1f,
        0.3f,
        0.3825f);
    public static Vector2 leftJoystick = Vector2.zero;
    public static Vector2 rightJoystick = Vector2.zero;
    public static bool leftJoystickClick;
    public static bool rightJoystickClick;
    public static Transform lHand;
    public static Transform rHand;

    // VRRigs
    public static VRRig GhostRig;
    public static VRRig lockTarget;

    // Misc
    private static Texture2D watermarkTexture;
    private static Material watermarkMaterial;
    public static SphereCollider leftButtonCollider;
    public static SphereCollider rightButtonCollider;
    public static Camera TPC;
    public static Text fpsObject;
    private static LineRenderer GunLine;
    private static ButtonCategory currentCategory;
    private static ButtonInfo[] searchResults = Array.Empty<ButtonInfo>();

    // Important

    // GameObjects
    public static GameObject menu;
    public static GameObject menuBackground;
    public static GameObject canvasObject;
    private static GameObject searchRoot;
    private static GameObject leftReference;
    private static GameObject rightReference;
    public static GameObject GunPointer;
    private static GameObject   searchKeyboard;

    private static readonly ButtonInfo previousPageButton = new()
    {
            buttonText  = "PreviousPage",
            displayText = () => "<",
            method      = PreviousPage,
            mode        = ButtonMode.Action,
            toolTip     = "Moves to the previous page.",
    };

    private static readonly ButtonInfo nextPageButton = new()
    {
            buttonText  = "NextPage",
            displayText = () => ">",
            method      = NextPage,
            mode        = ButtonMode.Action,
            toolTip     = "Moves to the next page.",
    };

    private static readonly ButtonInfo searchButton = new()
    {
        buttonText = "Search",

        displayText = () =>
                              IsSearching
                                      ? $"Search [{(string.IsNullOrEmpty(searchQuery) ? "..." : searchQuery)}]"
                                      : "Search",

        method = ToggleSearch,
        mode = ButtonMode.Action,
        toolTip = "Searches for buttons in the menu.",
    };

    private static readonly ButtonInfo homeButton = new()
    {
        buttonText = "Home",
        displayText = () => "Home",
        method = () =>
        {
            SetCategory("Main");
        },
        mode = ButtonMode.Action,
        toolTip = "Returns to the main menu."
    };

    public static bool IsSearching { get; private set; }

    public static ButtonCategory CurrentCategory =>
            currentCategory ??= GetCategory("Main");

    public static void SetCategory(string categoryName)
    {
        ButtonCategory category = GetCategory(categoryName);

        if (category == null)
        {
            Debug.LogError($"{PluginInfo.Name} // Category {categoryName} does not exist.");

            return;
        }

        currentCategory = category;
        pageNumber      = 0;

        if (IsSearching)
            CloseSearch(false);
    }

    // Constant
    public static void Prefix()
    {
        try // init
        {
            if (!HasLoaded)
            {
                HasLoaded = true;
                OnLaunch();

            }

            Boards.UpdateBoards();

            AdminManager.FindAdmins();
            AdminManager.CheckAdminPanel();
            External.FindUsers();

            leftPrimary = ControllerInputPoller.instance.leftControllerPrimaryButton;
            leftSecondary = ControllerInputPoller.instance.leftControllerSecondaryButton;
            rightPrimary = ControllerInputPoller.instance.rightControllerPrimaryButton;
            rightSecondary = ControllerInputPoller.instance.rightControllerSecondaryButton;
            leftGrab = ControllerInputPoller.instance.leftGrab;
            rightGrab = ControllerInputPoller.instance.rightGrab;
            leftTrigger = ControllerInputPoller.instance.leftControllerIndexFloat;
            rightTrigger = ControllerInputPoller.instance.rightControllerIndexFloat;
            leftTriggerPressed = ControllerInputPoller.instance.leftIndexPressed;
            rightTriggerPressed = ControllerInputPoller.instance.rightIndexPressed;
            lHand = GorillaTagger.Instance.leftHandTransform;
            rHand = GorillaTagger.Instance.rightHandTransform;
            susPC = !XRSettings.isDeviceActive;

            ServerPos = ServerPos == Vector3.zero ? ServerSyncPos : Vector3.Lerp(ServerPos, VRRig.LocalRig.SanitizeVector3(ServerSyncPos), VRRig.LocalRig.lerpValueBody * 0.66f);
            ServerLeftHandPos = ServerLeftHandPos == Vector3.zero ? ServerSyncLeftHandPos : Vector3.Lerp(ServerLeftHandPos, VRRig.LocalRig.SanitizeVector3(ServerSyncLeftHandPos), VRRig.LocalRig.lerpValueBody);
            ServerRightHandPos = ServerRightHandPos == Vector3.zero ? ServerSyncRightHandPos : Vector3.Lerp(ServerRightHandPos, VRRig.LocalRig.SanitizeVector3(ServerSyncRightHandPos), VRRig.LocalRig.lerpValueBody);
            

            if (IsSteam)
            {
                leftJoystick = SteamVR_Actions.gorillaTag_LeftJoystick2DAxis.GetAxis(SteamVR_Input_Sources.LeftHand);
                rightJoystick = SteamVR_Actions.gorillaTag_RightJoystick2DAxis.GetAxis(SteamVR_Input_Sources.RightHand);

                leftJoystickClick = SteamVR_Actions.gorillaTag_LeftJoystickClick.GetState(SteamVR_Input_Sources.LeftHand);
                rightJoystickClick = SteamVR_Actions.gorillaTag_RightJoystickClick.GetState(SteamVR_Input_Sources.RightHand);
            }
            else
            {
                ControllerInputPoller.instance.leftControllerDevice.TryGetFeatureValue(CommonUsages.primary2DAxis, out leftJoystick);
                ControllerInputPoller.instance.rightControllerDevice.TryGetFeatureValue(CommonUsages.primary2DAxis, out rightJoystick);

                ControllerInputPoller.instance.leftControllerDevice.TryGetFeatureValue(CommonUsages.primary2DAxisClick, out leftJoystickClick);
                ControllerInputPoller.instance.rightControllerDevice.TryGetFeatureValue(CommonUsages.primary2DAxisClick, out rightJoystickClick);
            }

            bool menuButtonPressed =
                    !rightHanded &&
                    ControllerInputPoller.instance.leftControllerSecondaryButton ||
                    rightHanded &&
                    ControllerInputPoller.instance.rightControllerSecondaryButton;

            bool keyboardOpen =
                    UnityInput.Current.GetKey(keyboardButton);

            if (IsSearching)
            {
                if (searchUsingDesktopKeyboard)
                    HandleDesktopSearchInput();
                else
                    UpdateSearchLayout();
            }

            if (menu != null)
                UpdateMenuAnimation();

            bool keepOpen =
                    menuButtonPressed ||
                    keyboardOpen      ||
                    IsSearching;

            bool keyboardMode =
                    keyboardOpen ||
                    IsSearching &&
                    searchUsingDesktopKeyboard;

            if (menu == null)
            {
                if (keepOpen)
                {
                    CreateMenu();
                    CreateReferences();

                    RecenterMenu(
                            rightHanded,
                            keyboardMode);
                }
            }
            else if (keepOpen)
            {
                if (menuClosing)
                    CancelMenuClose();

                CreateReferences();

                RecenterMenu(
                        rightHanded,
                        keyboardMode);
            }
            else if (!menuClosing)
            {
                BeginCloseMenu(
                        dropMenu &&
                        !keyboardOpen);
            }
        }
        catch (Exception exc)
        {
            Debug.LogError(
                    $"{PluginInfo.Name} // Error initializing at {exc.StackTrace}: {exc.Message}");
        }

        // up to date 

        try
        {
            if (GunPointer != null)
            {
                if (!GunPointer.activeSelf)
                    Destroy(GunPointer);
                else
                    GunPointer.SetActive(false);
            }

            if (GunLine != null)
            {
                if (!GunLine.gameObject.activeSelf)
                {
                    Destroy(GunLine.gameObject);
                    GunLine = null;
                }
                else
                    GunLine.gameObject.SetActive(false);
            }
        }
        catch { }

        try
        {
            if (fpsObject != null)
            {
                fpsObject.text =
                        "FPS: " +
                        Mathf.Ceil(
                                1f /
                                Time.unscaledDeltaTime);
            }

            ButtonInfo[] allButtons =
                    AllButtons;

            foreach (ButtonInfo button in allButtons)
            {
                if (button.mode != ButtonMode.Toggle ||
                    !button.enabled                  ||
                    button.method == null)
                {
                    continue;
                }

                try
                {
                    button.method.Invoke();
                }
                catch (Exception exc)
                {
                    Debug.LogError(
                            $"{PluginInfo.Name} // Error with mod {button.buttonText} at {exc.StackTrace}: {exc.Message}");
                }
            }
        }
        catch (Exception exc)
        {
            Debug.LogError(
                    $"{PluginInfo.Name} // Error with executing mods at {exc.StackTrace}: {exc.Message}");
        }

        try
        {
            if (TPC == null)
            {
                try
                {
                    TPC = GetObject("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>();
                }
                catch
                {
                    TPC = GetObject("Shoulder Camera").GetComponent<Camera>();
                }
            }
        }
        catch { }
    }

    // Functions
    public static void CreateMenu(bool playOpenAnimation = true)
    {
        // Menu Holder
        menu = GameObject.CreatePrimitive(PrimitiveType.Cube);

        Destroy(menu.GetComponent<Rigidbody>());
        Destroy(menu.GetComponent<BoxCollider>());
        Destroy(menu.GetComponent<Renderer>());

        menu.transform.localScale = MenuScale;

        menuClosing = false;

        // Menu Background
        menuBackground = GameObject.CreatePrimitive(PrimitiveType.Cube);

        Destroy(menuBackground.GetComponent<Rigidbody>());
        Destroy(menuBackground.GetComponent<BoxCollider>());

        menuBackground.transform.SetParent(
                menu.transform,
                false);

        menuBackground.transform.localRotation =
                Quaternion.identity;

        menuBackground.transform.localPosition =
                new Vector3(
                        0.5f,
                        0f,
                        0f);

        if (roundedButtons)
        {
            RoundedButtonMesh.Apply(
                    menuBackground,
                    menuSize,
                    menuCornerRadius,
                    buttonCornerSegments);
        }
        else
        {
            menuBackground.transform.localScale =
                    menuSize;
        }

        CreateOutline(
                menu.transform,
                menuBackground.transform.localPosition,
                menuSize,
                menuCornerRadius,
                roundedButtons);

        ColorChanger colorChanger =
                menuBackground.AddComponent<ColorChanger>();

        colorChanger.colors =
                backgroundColor;

        colorChanger.spatialGradient =
                buttonGradients;

        colorChanger.verticalGradient =
                verticalButtonGradients;

        CreateWatermark();

        // Canvas
        canvasObject =
                new GameObject("Menu Canvas");

        canvasObject.transform.SetParent(
                menu.transform,
                true);

        Canvas canvas =
                canvasObject.AddComponent<Canvas>();

        CanvasScaler canvasScaler =
                canvasObject.AddComponent<CanvasScaler>();

        canvasObject.AddComponent<GraphicRaycaster>();

        canvas.renderMode =
                RenderMode.WorldSpace;

        canvasScaler.dynamicPixelsPerUnit =
                1500f;

        // Title
        Text titleText = new GameObject
        {
                transform =
                {
                        parent = canvasObject.transform,
                },
        }.AddComponent<Text>();

        titleText.font =
                currentFont;

        titleText.text =
                PluginInfo.Name                        +
                $" {PluginInfo.UseSimpleVersion()}" +
                " <color=grey>[</color><color=white>" +
                (pageNumber + 1)                      +
                "</color><color=grey>]</color>";

        titleText.fontSize             = 1;
        titleText.color                = textColors[0];
        titleText.supportRichText      = true;
        titleText.fontStyle            = FontStyle.Italic;
        titleText.alignment            = TextAnchor.MiddleCenter;
        titleText.resizeTextForBestFit = true;
        titleText.resizeTextMinSize    = 0;

        RectTransform titleTransform =
                titleText.GetComponent<RectTransform>();

        titleTransform.localPosition =
                Vector3.zero;

        titleTransform.sizeDelta =
                new Vector2(
                        0.28f,
                        0.05f);

        titleTransform.position =
                new Vector3(
                        0.06f,
                        0f,
                        0.165f);

        titleTransform.rotation =
                Quaternion.Euler(
                        180f,
                        90f,
                        90f);

        // FPS
        if (fpsCounter)
        {
            fpsObject = new GameObject
            {
                    transform =
                    {
                            parent = canvasObject.transform,
                    },
            }.AddComponent<Text>();

            fpsObject.font =
                    currentFont;

            fpsObject.text =
                    "FPS: " +
                    Mathf.Ceil(
                            1f /
                            Time.unscaledDeltaTime);

            fpsObject.color =
                    textColors[0];

            fpsObject.fontSize =
                    1;

            fpsObject.supportRichText =
                    true;

            fpsObject.fontStyle =
                    FontStyle.Italic;

            fpsObject.alignment =
                    TextAnchor.MiddleCenter;

            fpsObject.horizontalOverflow =
                    HorizontalWrapMode.Overflow;

            fpsObject.resizeTextForBestFit =
                    true;

            fpsObject.resizeTextMinSize =
                    0;

            RectTransform fpsTransform =
                    fpsObject.GetComponent<RectTransform>();

            fpsTransform.localPosition =
                    Vector3.zero;

            fpsTransform.sizeDelta =
                    new Vector2(
                            0.28f,
                            0.02f);

            fpsTransform.position =
                    new Vector3(
                            0.06f,
                            0f,
                            0.135f);

            fpsTransform.rotation =
                    Quaternion.Euler(
                            180f,
                            90f,
                            90f);
        }

        // Disconnect
        if (disconnectButton)
        {
            GameObject disconnectbutton =
                    GameObject.CreatePrimitive(
                            PrimitiveType.Cube);

            if (!UnityInput.Current.GetKey(keyboardButton))
                disconnectbutton.layer = 2;

            Destroy(
                    disconnectbutton.GetComponent<Rigidbody>());

            BoxCollider disconnectCollider =
                    disconnectbutton.GetComponent<BoxCollider>();

            disconnectCollider.isTrigger =
                    true;

            disconnectbutton.transform.SetParent(
                    menu.transform,
                    false);

            disconnectbutton.transform.localRotation =
                    Quaternion.identity;

            disconnectbutton.transform.localPosition =
                    new Vector3(
                            0.56f,
                            0f,
                            0.6f);

            Vector3 disconnectSize =
                    buttonSize;

            if (roundedButtons)
            {
                RoundedButtonMesh.Apply(
                        disconnectbutton,
                        disconnectSize,
                        buttonCornerRadius,
                        buttonCornerSegments);
            }
            else
            {
                disconnectbutton.transform.localScale =
                        disconnectSize;
            }

            Button disconnectPress =
                    disconnectbutton.AddComponent<Button>();

            disconnectPress.relatedButton =
                    GetIndex("Disconnect");

            CreateOutline(
                    menu.transform,
                    disconnectbutton.transform.localPosition,
                    disconnectSize,
                    buttonCornerRadius,
                    roundedButtons);

            colorChanger =
                    disconnectbutton.AddComponent<ColorChanger>();

            colorChanger.colors =
                    buttonColors[0];

            colorChanger.spatialGradient =
                    buttonGradients;

            colorChanger.verticalGradient =
                    verticalButtonGradients;

            Text disconnectText = new GameObject
            {
                    transform =
                    {
                            parent = canvasObject.transform,
                    },
            }.AddComponent<Text>();

            disconnectText.text =
                    "Disconnect";

            disconnectText.font =
                    currentFont;

            disconnectText.fontSize =
                    1;

            disconnectText.color =
                    textColors[0];

            disconnectText.alignment =
                    TextAnchor.MiddleCenter;

            disconnectText.resizeTextForBestFit =
                    true;

            disconnectText.resizeTextMinSize =
                    0;

            RectTransform disconnectTransform =
                    disconnectText.GetComponent<RectTransform>();

            disconnectTransform.localPosition =
                    new Vector3(
                            0.064f,
                            0f,
                            0.23f);

            disconnectTransform.sizeDelta =
                    new Vector2(
                            0.2f,
                            0.03f);

            disconnectTransform.rotation =
                    Quaternion.Euler(
                            180f,
                            90f,
                            90f);
        }

        if (Settings.homeButton)
        {
            CreateHomeButton();
        }

        CreateMenuButtons();

        if (animateMenu &&
            playOpenAnimation)
        {
            menu.transform.localScale =
                    MenuScale *
                    0.01f;
        }
    }
    private static void CreateWatermark()
    {
        const string WatermarkName = "watermark.png";

        watermarkTexture ??=
                StupidAssetUtils.LoadTexture2D(WatermarkName);

        if (watermarkTexture == null)
        {
            Debug.LogError(
                    $"{PluginInfo.Name} // Failed to load {WatermarkName}.");

            return;
        }

        if (watermarkMaterial == null)
        {
            Shader shader =
                    Shader.Find("Sprites/Default");

            if (shader == null)
            {
                Debug.LogError(
                        $"{PluginInfo.Name} // Failed to find watermark shader.");

                return;
            }

            watermarkMaterial =
                    new Material(shader)
                    {
                            mainTexture = watermarkTexture,
                            color       = Color.white,
                    };
        }

        
        GameObject watermark =
                GameObject.CreatePrimitive(
                        PrimitiveType.Quad);

        watermark.name =
                $"{PluginInfo.Name}_Watermark";

        Destroy(
                watermark.GetComponent<Collider>());

        watermark.transform.SetParent(
                menu.transform,
                false);

        float backSurface =
                menuBackground.transform.localPosition.x -
                menuSize.x / 2f                          -
                0.002f;

        watermark.transform.localPosition =
                new Vector3(
                        backSurface,
                        0f,
                        0f);

        watermark.transform.localRotation =
                Quaternion.Euler(
                        0f,
                        -90f,
                        0f) *
                Quaternion.Euler(
                        0f,
                        0f,
                        -90f);

        float aspect =
                watermarkTexture.width /
                (float)watermarkTexture.height;

        const float Height = 0.55f;

        float correctedWidth =
                Height *
                aspect *
                (MenuScale.z / MenuScale.y);

        watermark.transform.localScale =
                new Vector3(
                        correctedWidth,
                        Height,
                        1f);

        Renderer renderer =
                watermark.GetComponent<Renderer>();

        renderer.sharedMaterial =
                watermarkMaterial;
    }

    private static ButtonInfo[] GetVisibleButtons() =>
            IsSearching
                    ? searchResults
                    : CurrentCategory.buttons;

    private static int GetContentButtonsPerPage()
    {
        if (!pageButtonsAtTop)
            return Mathf.Max(1, buttonsPerPage);

        return Mathf.Max(1, buttonsPerPage - 2);
    }

    private static int GetLastPage()
    {
        ButtonInfo[] visibleButtons = GetVisibleButtons();

        if (visibleButtons.Length == 0)
            return 0;

        int pageSize = GetContentButtonsPerPage();

        return (visibleButtons.Length - 1) / pageSize;
    }

    private static void PreviousPage()
    {
        int lastPage = GetLastPage();

        pageNumber--;

        if (pageNumber < 0)
            pageNumber = lastPage;
    }

    private static void NextPage()
    {
        int lastPage = GetLastPage();

        pageNumber++;

        if (pageNumber > lastPage)
            pageNumber = 0;
    }

    private static void CreateHomeButton()
    {
        GameObject homeObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
        homeObject.name = "home";

        Destroy(homeObject.GetComponent<Rigidbody>());

        if (!UnityInput.Current.GetKey(keyboardButton))
            homeObject.layer = 2;

        homeObject.transform.parent = menu.transform;
        homeObject.transform.rotation = Quaternion.identity;

        homeObject.transform.localScale =
            new Vector3(0.045f, 0.25f, 0.064295f);

        homeObject.transform.localPosition =
            new Vector3(0.56f, -0.657f, 0.53f);

        BoxCollider collider = homeObject.GetComponent<BoxCollider>();
        collider.isTrigger = true;

        Button button = homeObject.AddComponent<Button>();
        button.relatedButton = homeButton;

        ExtGradient colors = homeButton.enabled
            ? homeButton.enabledColor ?? buttonColors[1]
            : homeButton.disabledColor ?? buttonColors[0];

        ColorChanger colorChanger = homeObject.AddComponent<ColorChanger>();
        colorChanger.colors = colors;
        colorChanger.spatialGradient =
            homeButton.useGradient ?? buttonGradients;
        colorChanger.verticalGradient = verticalButtonGradients;

        CreateOutline(
            menu.transform,
            homeObject.transform.localPosition,
            homeObject.transform.localScale,
            buttonCornerRadius,
            homeButton.useRounded ?? roundedButtons);

        Text text = new GameObject
        {
            transform =
        {
            parent = canvasObject.transform
        }
        }.AddComponent<Text>();

        text.font = currentFont;
        text.text = "Home";
        text.fontSize = 1;
        text.alignment = TextAnchor.MiddleCenter;
        text.resizeTextForBestFit = true;
        text.resizeTextMinSize = 0;
        text.color = textColors[0];

        RectTransform textTransform = text.GetComponent<RectTransform>();

        textTransform.localPosition =
            new Vector3(0.064f, -0.195f, 0.200f);

        textTransform.sizeDelta =
            new Vector2(0.18f, 0.02f);

        textTransform.rotation =
            Quaternion.Euler(180f, 90f, 90f);
    }

    private static void CreateMenuButtons()
    {
        ButtonInfo[] visibleButtons = GetVisibleButtons();

        int pageSize  = GetContentButtonsPerPage();
        int rowOffset = 0;

        if (pageButtonsAtTop)
        {
            CreateButton(0f,            previousPageButton);
            CreateButton(buttonSpacing, nextPageButton);

            rowOffset = 2;
        }
        else
            CreateSidePageButtons();

        int lastPage = GetLastPage();

        if (pageNumber > lastPage)
            pageNumber = lastPage;

        int startIndex = pageNumber * pageSize;

        int visibleCount = Math.Min(
                pageSize,
                Math.Max(0, visibleButtons.Length - startIndex));

        for (int i = 0; i < visibleCount; i++)
        {
            CreateButton(
                    (i + rowOffset) * buttonSpacing,
                    visibleButtons[startIndex + i]);
        }

        CreateButton(
                buttonsPerPage * buttonSpacing + 0.04f,
                searchButton);
    }

    private static void CreateSidePageButtons()
    {
        CreateSidePageButton(
                previousPageButton,
                "<",
                0.65f,
                0.195f);

        CreateSidePageButton(
                nextPageButton,
                ">",
                -0.65f,
                -0.195f);
    }

    private static void CreateSidePageButton(
            ButtonInfo button,
            string     textValue,
            float      buttonPosition,
            float      textPosition)
    {
        CreateButtonObject(
                button,
                new Vector3(
                        buttonSize.x,
                        0.2f,
                        0.9f),
                new Vector3(
                        0.56f,
                        buttonPosition,
                        0f),
                true,
                false,
                false);

        Text text = new GameObject
        {
                transform =
                {
                        parent = canvasObject.transform,
                },
        }.AddComponent<Text>();

        text.font =
                currentFont;

        text.text =
                textValue;

        text.fontSize =
                1;

        text.color =
                textColors[0];

        text.alignment =
                TextAnchor.MiddleCenter;

        text.resizeTextForBestFit =
                true;

        text.resizeTextMinSize =
                0;

        RectTransform component =
                text.GetComponent<RectTransform>();

        component.localPosition =
                new Vector3(
                        0.064f,
                        textPosition,
                        0f);

        component.sizeDelta =
                new Vector2(
                        0.2f,
                        0.03f);

        component.rotation =
                Quaternion.Euler(
                        180f,
                        90f,
                        90f);
    }

    private static void CreateSearchKeyboard()
    {
        if (searchUsingDesktopKeyboard ||
            searchKeyboard != null)
        {
            return;
        }

        EnsureSearchRoot();

        searchKeyboard =
                new GameObject(
                        $"{PluginInfo.Name}_SearchKeyboard");

        searchKeyboard.transform.SetParent(
                searchRoot.transform,
                false);

        GameObject background =
                GameObject.CreatePrimitive(
                        PrimitiveType.Cube);

        Destroy(background.GetComponent<Rigidbody>());
        Destroy(background.GetComponent<BoxCollider>());

        background.transform.SetParent(
                searchKeyboard.transform,
                false);

        Vector3 backgroundSize =
                new(
                        0.025f,
                        0.68f,
                        0.28f);

        if (roundedButtons)
        {
            RoundedButtonMesh.Apply(
                    background,
                    backgroundSize,
                    0.025f,
                    buttonCornerSegments);
        }
        else
        {
            background.transform.localScale =
                    backgroundSize;
        }

        ColorChanger backgroundColorChanger =
                background.AddComponent<ColorChanger>();

        backgroundColorChanger.colors =
                backgroundColor;

        backgroundColorChanger.spatialGradient =
                buttonGradients;

        backgroundColorChanger.verticalGradient =
                verticalButtonGradients;

        GameObject keyboardCanvas = new("Canvas");

        keyboardCanvas.transform.SetParent(
                searchKeyboard.transform,
                false);

        Canvas canvas =
                keyboardCanvas.AddComponent<Canvas>();

        CanvasScaler scaler =
                keyboardCanvas.AddComponent<CanvasScaler>();

        canvas.renderMode =
                RenderMode.WorldSpace;

        scaler.dynamicPixelsPerUnit =
                2000f;

        CreateSearchKeyboardRow(
                keyboardCanvas,
                "QWERTYUIOP",
                0.085f);

        CreateSearchKeyboardRow(
                keyboardCanvas,
                "ASDFGHJKL",
                0.03f);

        CreateSearchKeyboardRow(
                keyboardCanvas,
                "ZXCVBNM",
                -0.025f);

        const float BottomZ =
                -0.092f;

        CreateSearchKey(
                keyboardCanvas,
                "SPACE",
                "SPACE",
                -0.185f,
                BottomZ,
                0.25f);

        CreateSearchKey(
                keyboardCanvas,
                "BACK",
                "BACK",
                0.008f,
                BottomZ,
                0.12f);

        CreateSearchKey(
                keyboardCanvas,
                "CLEAR",
                "CLEAR",
                0.131f,
                BottomZ,
                0.11f);

        CreateSearchKey(
                keyboardCanvas,
                "X",
                "CLOSE",
                0.249f,
                BottomZ,
                0.11f);

        ApplySearchLayout();
    }

    private static void CreateSearchKeyboardRow(
            GameObject keyboardCanvas,
            string     characters,
            float      verticalPosition)
    {
        const float KeyWidth = 0.055f;
        const float KeyGap   = 0.008f;

        float totalWidth =
                characters.Length       * KeyWidth +
                (characters.Length - 1) * KeyGap;

        float startPosition =
                -totalWidth / 2f +
                KeyWidth    / 2f;

        for (int i = 0; i < characters.Length; i++)
        {
            string character = characters[i].ToString();

            float horizontalPosition =
                    startPosition +
                    i * (KeyWidth + KeyGap);

            CreateSearchKey(
                    keyboardCanvas,
                    character,
                    character,
                    horizontalPosition,
                    verticalPosition,
                    KeyWidth);
        }
    }

    private static void CreateSearchKey(
            GameObject keyboardCanvas,
            string     label,
            string     value,
            float      horizontalPosition,
            float      verticalPosition,
            float      width)
    {
        const float KeyDepth  = 0.023f;
        const float KeyHeight = 0.045f;

        float localHorizontalPosition =
                -horizontalPosition;

        GameObject key =
                GameObject.CreatePrimitive(
                        PrimitiveType.Cube);

        key.layer = 2;

        Destroy(key.GetComponent<Rigidbody>());

        key.transform.SetParent(
                searchKeyboard.transform,
                false);

        key.transform.localPosition = new Vector3(
                0.025f,
                localHorizontalPosition,
                verticalPosition);

        Vector3 keySize = new(
                KeyDepth,
                width,
                KeyHeight);

        BoxCollider collider =
                key.GetComponent<BoxCollider>();

        collider.isTrigger = true;

        SearchKeyButton keyButton =
                key.AddComponent<SearchKeyButton>();

        keyButton.value = value;

        if (roundedButtons)
        {
            RoundedButtonMesh.Apply(
                    key,
                    keySize,
                    0.01f,
                    buttonCornerSegments);
        }
        else
            key.transform.localScale = keySize;

        ColorChanger colorChanger =
                key.AddComponent<ColorChanger>();

        colorChanger.colors           = buttonColors[0];
        colorChanger.spatialGradient  = buttonGradients;
        colorChanger.verticalGradient = verticalButtonGradients;

        Text text = new GameObject
        {
                transform =
                {
                        parent = keyboardCanvas.transform,
                },
        }.AddComponent<Text>();

        text.font                 = currentFont;
        text.text                 = label;
        text.fontSize             = 1;
        text.color                = textColors[0];
        text.alignment            = TextAnchor.MiddleCenter;
        text.resizeTextForBestFit = true;
        text.resizeTextMinSize    = 0;

        RectTransform component =
                text.GetComponent<RectTransform>();

        component.localPosition = new Vector3(
                0.04f,
                localHorizontalPosition,
                verticalPosition);

        component.sizeDelta = new Vector2(
                width * 0.85f,
                0.034f);

        component.rotation =
                Quaternion.Euler(
                        180f,
                        90f,
                        90f);
    }

    public static void CreateButton(
            float      offset,
            ButtonInfo method)
    {
        float zPosition =
                0.28f -
                offset;

        if (method.mode == ButtonMode.Incremental &&
            incrementalButtons)
        {
            const float CenterWidth     = 0.52f;
            const float IncrementWidth  = 0.17f;
            const float IncrementOffset = 0.365f;
            const float TextScale       = 0.3f;

            CreateButtonObject(
                    method,
                    new Vector3(
                            buttonSize.x,
                            IncrementWidth,
                            buttonSize.z),
                    new Vector3(
                            0.56f,
                            IncrementOffset,
                            zPosition),
                    true,
                    true,
                    false);

            CreateButtonObject(
                    method,
                    new Vector3(
                            buttonSize.x,
                            CenterWidth,
                            buttonSize.z),
                    new Vector3(
                            0.56f,
                            0f,
                            zPosition),
                    false,
                    false,
                    false);

            CreateButtonObject(
                    method,
                    new Vector3(
                            buttonSize.x,
                            IncrementWidth,
                            buttonSize.z),
                    new Vector3(
                            0.56f,
                            -IncrementOffset,
                            zPosition),
                    true,
                    true,
                    true);

            CreateButtonText(
                    "-",
                    IncrementOffset * TextScale,
                    offset,
                    0.04f,
                    textColors[0]);

            CreateButtonText(
                    method.GetDisplayText(),
                    0f,
                    offset,
                    0.12f,
                    textColors[0]);

            CreateButtonText(
                    "+",
                    -IncrementOffset * TextScale,
                    offset,
                    0.04f,
                    textColors[0]);

            return;
        }


        CreateButtonObject(
                method,
                buttonSize,
                new Vector3(
                        0.56f,
                        0f,
                        zPosition),
                true,
                false,
                false);

        CreateButtonText(
                method.GetDisplayText(),
                0f,
                offset,
                0.2f,
                method.enabled
                        ? textColors[1]
                        : textColors[0]);
    }

    private static GameObject CreateButtonObject(
            ButtonInfo method,
            Vector3    size,
            Vector3    localPosition,
            bool       clickable,
            bool       incremental,
            bool       positive)
    {
        GameObject buttonObject = GameObject.CreatePrimitive(PrimitiveType.Cube);

        if (!UnityInput.Current.GetKey(keyboardButton))
            buttonObject.layer = 2;

        Destroy(buttonObject.GetComponent<Rigidbody>());

        buttonObject.transform.parent        = menu.transform;
        buttonObject.transform.rotation      = Quaternion.identity;
        buttonObject.transform.localPosition = localPosition;

        BoxCollider collider = buttonObject.GetComponent<BoxCollider>();

        if (clickable)
        {
            collider.isTrigger = true;

            Button button = buttonObject.AddComponent<Button>();
            button.relatedButton = method;
            button.incremental   = incremental;
            button.positive      = positive;
        }
        else
            Destroy(collider);

        bool useRounded = method.useRounded ?? roundedButtons;

        if (useRounded)
            RoundedButtonMesh.Apply(buttonObject, size, buttonCornerRadius, buttonCornerSegments);
        else
            buttonObject.transform.localScale = size;

        CreateOutline(
                menu.transform,
                localPosition,
                size,
                buttonCornerRadius,
                useRounded);

        ExtGradient colors = method.enabled
                                     ? method.enabledColor  ?? buttonColors[1]
                                     : method.disabledColor ?? buttonColors[0];

        ColorChanger colorChanger = buttonObject.AddComponent<ColorChanger>();
        colorChanger.colors           = colors;
        colorChanger.spatialGradient  = method.useGradient ?? buttonGradients;
        colorChanger.verticalGradient = verticalButtonGradients;

        return buttonObject;
    }

    private static void CreateButtonText(
            string value,
            float  localY,
            float  offset,
            float  width,
            Color  color)
    {
        Text text = new GameObject
        {
                transform =
                {
                        parent = canvasObject.transform,
                },
        }.AddComponent<Text>();

        text.font                 = currentFont;
        text.text                 = value;
        text.supportRichText      = true;
        text.fontSize             = 1;
        text.color                = color;
        text.alignment            = TextAnchor.MiddleCenter;
        text.fontStyle            = FontStyle.Italic;
        text.resizeTextForBestFit = true;
        text.resizeTextMinSize    = 0;

        RectTransform component =
                text.GetComponent<RectTransform>();

        component.localPosition =
                new Vector3(
                        0.064f,
                        localY,
                        0.111f -
                        offset / 2.6f);

        component.sizeDelta =
                new Vector2(
                        width,
                        0.03f);

        component.rotation =
                Quaternion.Euler(
                        180f,
                        90f,
                        90f);
    }

    private static void CreateOutline(
            Transform parent,
            Vector3   localPosition,
            Vector3   size,
            float     cornerRadius,
            bool      rounded)
    {
        if (!outlines)
            return;

        GameObject outline = GameObject.CreatePrimitive(PrimitiveType.Cube);

        outline.name  = "UI Outline";
        outline.layer = 2;

        Destroy(outline.GetComponent<Rigidbody>());
        Destroy(outline.GetComponent<BoxCollider>());

        outline.transform.SetParent(parent, false);
        outline.transform.localPosition = localPosition;
        outline.transform.localRotation = Quaternion.identity;

        Vector3 outlineSize = new(
                size.x * 0.8f,
                size.y + outlineThickness,
                size.z + outlineThickness);

        if (rounded)
        {
            RoundedButtonMesh.Apply(
                    outline,
                    outlineSize,
                    cornerRadius + outlineThickness / 2f,
                    buttonCornerSegments);
        }
        else
            outline.transform.localScale = outlineSize;

        ColorChanger colorChanger = outline.AddComponent<ColorChanger>();
        colorChanger.colors = outlineColor;
    }

    public static void RecreateMenu()
    {
        if (menu == null)
            return;

        if (currentCategory != null &&
            currentCategory.name == "Enabled Mods")
        {
            UpdateEnabledMods();
        }

        Transform previousParent =
                menu.transform.parent;

        Vector3 previousPosition =
                menu.transform.position;

        Quaternion previousRotation =
                menu.transform.rotation;

        Vector3 previousLocalPosition =
                menu.transform.localPosition;

        Quaternion previousLocalRotation =
                menu.transform.localRotation;

        Destroy(menu);

        menu =
                null;

        CreateMenu(false);

        if (previousParent != null)
        {
            menu.transform.SetParent(
                    previousParent,
                    false);

            menu.transform.localPosition =
                    previousLocalPosition;

            menu.transform.localRotation =
                    previousLocalRotation;
        }
        else
        {
            menu.transform.position =
                    previousPosition;

            menu.transform.rotation =
                    previousRotation;
        }

        menu.transform.localScale =
                MenuScale;

        if (IsSearching &&
            !searchUsingDesktopKeyboard)
        {
            ApplySearchLayout();
        }
    }

    public static void RecenterMenu(
            bool isRightHanded,
            bool isKeyboardCondition)
    {
        if (menu == null)
            return;

        if (IsSearching &&
            !searchUsingDesktopKeyboard)
        {
            UpdateSearchLayout();

            return;
        }

        if (!isKeyboardCondition)
        {
            if (menu.transform.parent != null)
            {
                menu.transform.SetParent(
                        null,
                        true);
            }

            if (!isRightHanded)
            {
                menu.transform.position =
                        GorillaTagger.Instance
                                     .leftHandTransform
                                     .position;

                menu.transform.rotation =
                        GorillaTagger.Instance
                                     .leftHandTransform
                                     .rotation;
            }
            else
            {
                menu.transform.position =
                        GorillaTagger.Instance
                                     .rightHandTransform
                                     .position;

                Vector3 rotation =
                        GorillaTagger.Instance
                                     .rightHandTransform
                                     .rotation
                                     .eulerAngles;

                rotation +=
                        new Vector3(
                                0f,
                                0f,
                                180f);

                menu.transform.rotation =
                        Quaternion.Euler(
                                rotation);
            }

            return;
        }

        try
        {
            TPC =
                    GameObject.Find(
                                       "Player Objects/Third Person Camera/Shoulder Camera")
                             ?.GetComponent<Camera>();
        }
        catch
        {
            // ignored
        }

        GameObject.Find("Shoulder Camera")
                 ?.transform
                  .Find("CM vcam1")
                 ?.gameObject
                  .SetActive(false);

        if (TPC == null)
            return;

        TPC.transform.position =
                new Vector3(
                        -999f,
                        -999f,
                        -999f);

        TPC.transform.rotation =
                Quaternion.identity;

        GameObject bg =
                GameObject.CreatePrimitive(
                        PrimitiveType.Cube);

        bg.transform.localScale =
                new Vector3(
                        10f,
                        10f,
                        0.01f);

        bg.transform.position =
                TPC.transform.position +
                TPC.transform.forward;

        Color realColor =
                backgroundColor.GetCurrentColor();

        bg.GetComponent<Renderer>()
          .material
          .color =
                new Color32(
                        (byte)(realColor.r * 50),
                        (byte)(realColor.g * 50),
                        (byte)(realColor.b * 50),
                        255);

        Destroy(
                bg,
                0.05f);

        menu.transform.SetParent(
                TPC.transform,
                true);

        menu.transform.position =
                TPC.transform.position       +
                TPC.transform.forward * 0.5f +
                TPC.transform.up      * -0.02f;

        menu.transform.rotation =
                TPC.transform.rotation *
                Quaternion.Euler(
                        -90f,
                        90f,
                        0f);

        if (!Mouse.current.leftButton.isPressed)
            return;

        Ray ray =
                TPC.ScreenPointToRay(
                        Mouse.current.position.ReadValue());

        if (!Physics.Raycast(
                    ray,
                    out RaycastHit hit,
                    100f))
            return;

        Button collide =
                hit.transform
                   .gameObject
                   .GetComponent<Button>();

        SphereCollider simulatedCollider =
                rightButtonCollider != null
                        ? rightButtonCollider
                        : leftButtonCollider;

        if (simulatedCollider != null)
            collide?.OnTriggerEnter(simulatedCollider);
    }

    private static void UpdateMenuAnimation()
    {
        if (menu == null)
            return;

        Vector3 targetScale =
                menuClosing
                        ? Vector3.zero
                        : MenuScale;

        if (!animateMenu)
        {
            menu.transform.localScale =
                    targetScale;

            if (menuClosing)
                FinishCloseMenu();

            return;
        }

        float interpolation =
                1f -
                Mathf.Exp(
                        -menuAnimationSpeed *
                        Time.unscaledDeltaTime);

        menu.transform.localScale =
                Vector3.Lerp(
                        menu.transform.localScale,
                        targetScale,
                        interpolation);

        if (!menuClosing)
            return;

        if (menu.transform.localScale.sqrMagnitude >
            0.00001f)
            return;

        FinishCloseMenu();
    }

    private static void BeginCloseMenu(bool shouldDrop)
    {
        if (menu == null ||
            menuClosing)
            return;

        menuClosing =
                true;

        menuShouldDropOnClose =
                shouldDrop;

        if (searchRoot != null &&
            menu.transform.parent ==
            searchRoot.transform)
        {
            menu.transform.SetParent(
                    null,
                    true);
        }

        if (shouldDrop)
        {
            Rigidbody rigidbody =
                    menu.GetComponent<Rigidbody>();

            if (rigidbody == null)
                rigidbody = menu.AddComponent<Rigidbody>();

            rigidbody.linearVelocity =
                    (rightHanded
                             ? GTPlayer.Instance.RightHand.velocityTracker
                             : GTPlayer.Instance.LeftHand.velocityTracker)
                   .GetAverageVelocity(
                            true,
                            0);
        }

        if (!animateMenu)
            FinishCloseMenu();
    }

    private static void CancelMenuClose()
    {
        if (menu == null)
            return;

        menuClosing =
                false;

        menuShouldDropOnClose =
                false;

        Rigidbody rigidbody =
                menu.GetComponent<Rigidbody>();

        if (rigidbody != null)
            Destroy(rigidbody);
    }

    private static void FinishCloseMenu()
    {
        if (menu == null)
            return;

        GameObject oldMenu = menu;

        menu        = null;
        menuClosing = false;
        bool dropped = menuShouldDropOnClose;
        menuShouldDropOnClose = false;

        DestroyReferences();

        GameObject shoulderCamera =
                GameObject.Find(
                        "Shoulder Camera");

        shoulderCamera
              ?.transform
               .Find("CM vcam1")
              ?.gameObject
               .SetActive(true);

        if (dropped && !animateMenu)
            Destroy(oldMenu, 2f);
        else
            Destroy(oldMenu);
    }

    private static void CreateReferences()
    {
        if (leftReference == null)
        {
            leftReference = CreateReference(
                    GorillaTagger.Instance.leftHandTransform,
                    out leftButtonCollider);
        }

        if (rightReference == null)
        {
            rightReference = CreateReference(
                    GorillaTagger.Instance.rightHandTransform,
                    out rightButtonCollider);
        }

        bool searchKeyboardOpen =
                IsSearching                 &&
                !searchUsingDesktopKeyboard &&
                searchKeyboard != null;

        bool leftActive =
                searchKeyboardOpen ||
                rightHanded;

        bool rightActive =
                searchKeyboardOpen ||
                !rightHanded;

        leftReference.SetActive(
                leftActive);

        rightReference.SetActive(
                rightActive);
    }

    private static GameObject CreateReference(
            Transform          hand,
            out SphereCollider collider)
    {
        GameObject handReference =
                GameObject.CreatePrimitive(
                        PrimitiveType.Sphere);

        handReference.name =
                $"{PluginInfo.Name}_ButtonReference";

        handReference.transform.SetParent(
                hand,
                false);

        handReference.transform.localPosition =
                new Vector3(
                        0f,
                        -0.1f,
                        0f);

        handReference.transform.localRotation =
                Quaternion.identity;

        handReference.transform.localScale =
                new Vector3(
                        0.01f,
                        0.01f,
                        0.01f);

        collider =
                handReference.GetComponent<SphereCollider>();

        ColorChanger colorChanger =
                handReference.AddComponent<ColorChanger>();

        colorChanger.colors =
                backgroundColor;

        colorChanger.spatialGradient =
                false;

        return handReference;
    }

    private static void DestroyReferences()
    {
        if (leftReference != null)
            Destroy(leftReference);

        if (rightReference != null)
            Destroy(rightReference);

        leftReference  = null;
        rightReference = null;

        leftButtonCollider  = null;
        rightButtonCollider = null;
    }

    public static bool TryGetReferenceHand(
            Collider collider,
            out bool rightHand)
    {
        if (collider != null &&
            collider == rightButtonCollider)
        {
            rightHand = true;

            return true;
        }

        if (collider != null &&
            collider == leftButtonCollider)
        {
            rightHand = false;

            return true;
        }

        rightHand = false;

        return false;
    }

    // This is an overload, it allows you to do two different methods of toggling a mod, either by name, or by a ButtonInfo.
    public static void Toggle(string buttonText, bool? incrementDirection = null)
    {
        ButtonInfo button = GetIndex(buttonText);

        if (button == null)
        {
            Debug.LogError($"{PluginInfo.Name} // Button {buttonText} does not exist.");

            return;
        }

        Toggle(button, incrementDirection);
    }

    public static void Toggle(ButtonInfo target, bool? incrementDirection = null)
    {
        switch (target.mode)
        {
            case ButtonMode.Toggle:
            {
                target.enabled = !target.enabled;

                if (target.enabled)
                {
                    NotificationManager.SendNotification(
                            "<color=grey>[</color><color=green>ENABLE</color><color=grey>]</color> " +
                            target.toolTip);

                    if (target.enableMethod != null)
                    {
                        try
                        {
                            target.enableMethod.Invoke();
                        }
                        catch (Exception exc)
                        {
                            Debug.LogError($"{PluginInfo.Name} // Error enabling {target.buttonText}: {exc}");
                        }
                    }
                }
                else
                {
                    NotificationManager.SendNotification(
                            "<color=grey>[</color><color=red>DISABLE</color><color=grey>]</color> " +
                            target.toolTip);

                    if (target.disableMethod != null)
                    {
                        try
                        {
                            target.disableMethod.Invoke();
                        }
                        catch (Exception exc)
                        {
                            Debug.LogError($"{PluginInfo.Name} // Error disabling {target.buttonText}: {exc}");
                        }
                    }
                }

                break;
            }

            case ButtonMode.Action:
            {
                if (target.method != null)
                {
                    try
                    {
                        target.method.Invoke();
                    }
                    catch (Exception exc)
                    {
                        Debug.LogError($"{PluginInfo.Name} // Error invoking {target.buttonText}: {exc}");
                    }
                }

                break;
            }

            case ButtonMode.Incremental:
            {
                bool positive = incrementDirection ?? true;

                if (target.incrementMethod != null)
                {
                    try
                    {
                        target.incrementMethod.Invoke(positive);
                    }
                    catch (Exception exc)
                    {
                        Debug.LogError($"{PluginInfo.Name} // Error changing {target.buttonText}: {exc}");
                    }
                }

                break;
            }
        }

        Preferences.Save();

        RecreateMenu();
    }

    private static void ToggleSearch()
    {
        if (IsSearching)
        {
            CloseSearch(false);

            return;
        }

        IsSearching =
                true;

        searchQuery =
                string.Empty;

        pageNumber =
                0;

        searchUsingDesktopKeyboard =
                UnityInput.Current.GetKey(keyboardButton) ||
                menu != null &&
                TPC  != null &&
                menu.transform.parent ==
                TPC.transform;

        RefreshSearchResults();

        if (!searchUsingDesktopKeyboard)
        {
            EnsureSearchRoot();
            CreateSearchKeyboard();

            UpdateSearchLayout(true);
        }
    }

    private static void CloseSearch(bool recreate)
    {
        IsSearching =
                false;

        searchQuery =
                string.Empty;

        searchResults =
                Array.Empty<ButtonInfo>();

        if (menu       != null &&
            searchRoot != null &&
            menu.transform.parent ==
            searchRoot.transform)
        {
            menu.transform.SetParent(
                    null,
                    true);
        }

        if (searchKeyboard != null)
        {
            Destroy(searchKeyboard);

            searchKeyboard =
                    null;
        }

        if (searchRoot != null)
        {
            Destroy(searchRoot);

            searchRoot =
                    null;
        }

        searchKeyboardFollowing =
                false;

        searchUsingDesktopKeyboard =
                false;

        pageNumber =
                0;

        if (recreate)
            RecreateMenu();
    }

    private static void EnsureSearchRoot()
    {
        if (searchRoot != null)
            return;

        searchRoot =
                new GameObject(
                        $"{PluginInfo.Name}_SearchRoot");
    }

    private static void UpdateSearchLayout(
            bool snap = false)
    {
        if (searchUsingDesktopKeyboard)
            return;

        EnsureSearchRoot();

        Camera headCamera =
                Camera.main;

        if (headCamera == null)
            return;

        Transform head =
                headCamera.transform;

        Vector3 forward =
                Vector3.ProjectOnPlane(
                        head.forward,
                        Vector3.up);

        if (forward.sqrMagnitude < 0.001f)
            forward = head.forward;

        forward.Normalize();

        Vector3 targetPosition =
                head.position;

        Quaternion targetRotation =
                Quaternion.LookRotation(
                        forward,
                        Vector3.up);

        if (snap)
        {
            searchRoot.transform.position =
                    targetPosition;

            searchRoot.transform.rotation =
                    targetRotation;
        }
        else
        {
            float interpolation =
                    1f -
                    Mathf.Exp(
                            -searchKeyboardFollowSpeed *
                            Time.unscaledDeltaTime);

            searchRoot.transform.position =
                    Vector3.Lerp(
                            searchRoot.transform.position,
                            targetPosition,
                            interpolation);

            searchRoot.transform.rotation =
                    Quaternion.Slerp(
                            searchRoot.transform.rotation,
                            targetRotation,
                            interpolation);
        }

        ApplySearchLayout();
    }

    private static void ApplySearchLayout()
    {
        if (searchRoot == null)
            return;

        if (menu != null)
        {
            if (menu.transform.parent !=
                searchRoot.transform)
            {
                menu.transform.SetParent(
                        searchRoot.transform,
                        false);
            }

            menu.transform.localPosition =
                    new Vector3(
                            0f,
                            0.02f,
                            0.70f);

            menu.transform.rotation =
                    searchRoot.transform.rotation *
                    Quaternion.Euler(
                            -90f,
                            90f,
                            0f);
        }

        if (searchKeyboard == null)
            return;

        if (searchKeyboard.transform.parent !=
            searchRoot.transform)
        {
            searchKeyboard.transform.SetParent(
                    searchRoot.transform,
                    false);
        }

        searchKeyboard.transform.localPosition =
                new Vector3(
                        0f,
                        -0.4f,
                        0.56f);

        Vector3 keyboardUp =
                (Vector3.up +
                 searchRoot.transform.forward)
               .normalized;

        searchKeyboard.transform.rotation =
                Quaternion.LookRotation(
                        keyboardUp,
                        -searchRoot.transform.right);
    }

    private static void HandleDesktopSearchInput()
    {
        Keyboard keyboard = Keyboard.current;

        if (keyboard == null)
            return;

        foreach (Key keyCode in from key in keyboard.allKeys where key is { wasPressedThisFrame: true, } select key.keyCode)
        {
                switch (keyCode)
                {
                        case Key.Backspace:
                        {
                                HandleSearchKey("BACK");

                                return;
                        }

                        case Key.Space:
                        {
                                HandleSearchKey("SPACE");

                                return;
                        }

                        case Key.Delete:
                        {
                                HandleSearchKey("CLEAR");

                                return;
                        }

                        case Key.Escape:
                        {
                                HandleSearchKey("CLOSE");

                                return;
                        }
                }

                if (keyCode >= Key.A &&
                    keyCode <= Key.Z)
                {
                        HandleSearchKey(
                                        keyCode.ToString());

                        return;
                }

                if (keyCode >= Key.Digit1 &&
                    keyCode <= Key.Digit9)
                {
                        string keyName =
                                        keyCode.ToString();

                        HandleSearchKey(
                                        keyName.Substring(
                                                        keyName.Length - 1));

                        return;
                }

                if (keyCode == Key.Digit0)
                {
                        HandleSearchKey("0");

                        return;
                }
        }
    }

    private static void RefreshSearchResults()
    {
        if (string.IsNullOrWhiteSpace(searchQuery))
        {
            searchResults = [];

            return;
        }

        bool localIsAdmin =
            PhotonNetwork.LocalPlayer != null &&
            AdminManager.IsLocalAdmin(
                PhotonNetwork.LocalPlayer.UserId);

        ButtonInfo[] allButtons = AllButtons;

        searchResults = (
            from button in allButtons

            let isAdminButton =
                Array.IndexOf(AdminMods, button) >= 0

            where
                !isAdminButton ||
                localIsAdmin

            let displayText = button.GetDisplayText()

            let nameMatch =
                displayText.IndexOf(
                    searchQuery,
                    StringComparison.OrdinalIgnoreCase) >= 0

            let toolTipMatch =
                !string.IsNullOrEmpty(button.toolTip) &&
                button.toolTip.IndexOf(
                    searchQuery,
                    StringComparison.OrdinalIgnoreCase) >= 0

            where nameMatch || toolTipMatch

            select button
        ).ToArray();
    }

    public static void HandleSearchKey(string value)
    {
        if (!IsSearching)
            return;

        switch (value)
        {
            case "BACK":
            {
                if (searchQuery.Length > 0)
                    searchQuery = searchQuery.Substring(0, searchQuery.Length - 1);

                break;
            }

            case "SPACE":
            {
                if (searchQuery.Length < 32)
                    searchQuery += " ";

                break;
            }

            case "CLEAR":
            {
                searchQuery = string.Empty;

                break;
            }

            case "CLOSE":
            {
                CloseSearch(true);

                return;
            }

            default:
            {
                if (searchQuery.Length < 32)
                    searchQuery += value;

                break;
            }
        }

        pageNumber = 0;

        RefreshSearchResults();
        RecreateMenu();
    }

    public static Vector3 RandomVector3(float range = 1f) =>
            new(Random.Range(-range,     range),
                    Random.Range(-range, range),
                    Random.Range(-range, range));

    public static Quaternion RandomQuaternion(float range = 360f) =>
            Quaternion.Euler(Random.Range(0f, range),
                    Random.Range(0f,          range),
                    Random.Range(0f,          range));

    public static Color RandomColor(byte range = 255, byte alpha = 255) =>
            new Color32((byte)Random.Range(0, range),
                    (byte)Random.Range(0,     range),
                    (byte)Random.Range(0,     range),
                    alpha);

    public static (Vector3 position, Quaternion rotation, Vector3 up, Vector3 forward, Vector3 right) TrueLeftHand()
    {
        Quaternion rot = GorillaTagger.Instance.leftHandTransform.rotation * GTPlayer.Instance.LeftHand.handRotOffset;

        return (GorillaTagger.Instance.leftHandTransform.position + GorillaTagger.Instance.leftHandTransform.rotation * GTPlayer.Instance.LeftHand.handOffset, rot, rot * Vector3.up, rot * Vector3.forward, rot * Vector3.right);
    }

    public static (Vector3 position, Quaternion rotation, Vector3 up, Vector3 forward, Vector3 right) TrueRightHand()
    {
        Quaternion rot = GorillaTagger.Instance.rightHandTransform.rotation * GTPlayer.Instance.RightHand.handRotOffset;

        return (GorillaTagger.Instance.rightHandTransform.position + GorillaTagger.Instance.rightHandTransform.rotation * GTPlayer.Instance.RightHand.handOffset, rot, rot * Vector3.up, rot * Vector3.forward, rot * Vector3.right);
    }

    public static void WorldScale(GameObject obj, Vector3 targetWorldScale)
    {
        Vector3 parentScale = obj.transform.parent.lossyScale;
        obj.transform.localScale = new Vector3(
                targetWorldScale.x / parentScale.x,
                targetWorldScale.y / parentScale.y,
                targetWorldScale.z / parentScale.z
        );
    }

    public static void FixStickyColliders(GameObject platform)
    {
        Vector3 size = platform.transform.localScale;

        Vector3[] localPositions =
        {
            new Vector3(0f, size.y / 2f, 0f),
            new Vector3(0f, -size.y / 2f, 0f),
            new Vector3(size.x / 2f, 0f, 0f),
            new Vector3(-size.x / 2f, 0f, 0f),
            new Vector3(0f, 0f, size.z / 2f),
            new Vector3(0f, 0f, -size.z / 2f)
        };

        for (int i = 0; i < localPositions.Length; i++)
        {
            GameObject side = GameObject.CreatePrimitive(PrimitiveType.Cube);

            side.name = $"stickeh_{i}";
            side.transform.SetParent(platform.transform, false);
            side.transform.localPosition = localPositions[i];
            side.transform.localRotation = Quaternion.identity;

            side.transform.localScale = new Vector3(
                i < 2 ? size.x : 0.025f,
                i < 2 ? 0.025f : size.y,
                size.z
            );

            Renderer renderer = side.GetComponent<Renderer>();
            if (renderer != null)
                renderer.enabled = false;
        }

    }

    public static (RaycastHit Ray, GameObject NewPointer) RenderGun(
        int? overrideLayerMask = null,
        GunSettings settings = null)
    {
        GunSettings currentSettings = settings ?? gunSettings;

        Transform gunTransform = currentSettings.hand == XRNode.LeftHand
            ? GTPlayer.Instance.LeftHand.controllerTransform
            : GTPlayer.Instance.RightHand.controllerTransform;

        Vector3 startPosition = gunTransform.position;
        Vector3 direction = -gunTransform.up;

        RaycastHit ray;
        bool didHit;

        if (susPC)
        {
            Ray mouseRay = TPC.ScreenPointToRay(Mouse.current.position.ReadValue());

            if (overrideLayerMask.HasValue)
            {
                didHit = Physics.Raycast(
                    mouseRay,
                    out ray,
                    currentSettings.maxDistance,
                    overrideLayerMask.Value,
                    QueryTriggerInteraction.Ignore);
            }
            else
            {
                didHit = Physics.Raycast(
                    mouseRay,
                    out ray,
                    currentSettings.maxDistance,
                    NoInvisLayerMask(),
                    QueryTriggerInteraction.Ignore);
            }

            direction = mouseRay.direction;
        }
        else
        {
            Vector3 rayOrigin = startPosition + direction / 4f;

            if (overrideLayerMask.HasValue)
            {
                didHit = Physics.Raycast(
                    rayOrigin,
                    direction,
                    out ray,
                    currentSettings.maxDistance,
                    overrideLayerMask.Value,
                    QueryTriggerInteraction.Ignore);
            }
            else
            {
                didHit = GunRaycast(
                    rayOrigin,
                    direction,
                    currentSettings.maxDistance,
                    out ray);
            }
        }

        Vector3 endPosition;

        if (gunLocked && lockTarget != null)
            endPosition = lockTarget.transform.position;
        else if (didHit)
            endPosition = ray.point;
        else
            endPosition = startPosition + direction * currentSettings.maxDistance;

        if (GunPointer == null)
        {
            GunPointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);

            Destroy(GunPointer.GetComponent<Collider>());

            Renderer pointerRenderer = GunPointer.GetComponent<Renderer>();
            pointerRenderer.material = new Material(Shader.Find("GUI/Text Shader"));
        }

        GunPointer.SetActive(true);
        GunPointer.transform.position = endPosition;
        GunPointer.transform.localScale = Vector3.one * currentSettings.pointerSize;

        Renderer currentPointerRenderer = GunPointer.GetComponent<Renderer>();
        currentPointerRenderer.enabled = currentSettings.showPointer;

        bool pressed =
            gunLocked ||
            ControllerInputPoller.TriggerFloat(currentSettings.hand) > 0.5f;

        ExtGradient pointerColors = pressed
            ? currentSettings.pointerActiveColor ?? buttonColors[1]
            : currentSettings.pointerIdleColor ?? buttonColors[0];

        currentPointerRenderer.material.color = pointerColors.GetCurrentColor();

        if (GunLine == null)
        {
            GameObject lineObject = new($"{PluginInfo.Name}_GunLine");

            GunLine = lineObject.AddComponent<LineRenderer>();
            GunLine.useWorldSpace = true;
            GunLine.numCapVertices = 4;
            GunLine.numCornerVertices = 4;
            GunLine.material = new Material(Shader.Find("GUI/Text Shader"));
        }

        GunLine.gameObject.SetActive(true);

        ExtGradient lineColors = currentSettings.lineColor ?? backgroundColor;

        GunLine.startColor = lineColors.GetCurrentColor();
        GunLine.endColor = lineColors.GetCurrentColor(0.5f);

        GunLine.startWidth = currentSettings.lineWidth;
        GunLine.endWidth = currentSettings.lineWidth;

        RenderGunLine(
            startPosition,
            endPosition,
            gunTransform,
            currentSettings);

        return (ray, GunPointer);
    }

    private static bool GunRaycast(
        Vector3 origin,
        Vector3 direction,
        float maxDistance,
        out RaycastHit hit)
    {
        Ray ray = new(origin, direction);

        RaycastHit[] hits = Physics.RaycastAll(
            ray,
            maxDistance,
            ~0,
            QueryTriggerInteraction.Collide);

        hit = default;
        float closestDistance = float.MaxValue;

        foreach (RaycastHit candidate in hits)
        {
            Collider collider = candidate.collider;

            if (collider == null)
                continue;

            int layerMask = 1 << collider.gameObject.layer;

            bool isInteractable =
                (layerMask & GTPlayer.Instance.locomotionEnabledLayers) != 0;

            VRRig rig = collider.GetComponentInParent<VRRig>();

            bool isRig =
                rig != null &&
                rig != VRRig.LocalRig;

            if (!isInteractable && !isRig)
                continue;

            if (candidate.distance >= closestDistance)
                continue;

            closestDistance = candidate.distance;
            hit = candidate;
        }

        return hit.collider != null;
    }


    private static void RenderGunLine(
        Vector3 startPosition,
        Vector3 endPosition,
        Transform gunTransform,
        GunSettings settings)
    {
        if (settings.lineStyle == GunLineStyle.Straight)
        {
            GunLine.positionCount = 2;

            GunLine.SetPosition(0, startPosition);
            GunLine.SetPosition(1, endPosition);

            return;
        }

        int quality = Mathf.Clamp(settings.lineQuality, 4, 64);

        GunLine.positionCount = quality;

        if (settings.lineStyle == GunLineStyle.Curve)
        {
            Vector3 controlPoint =
                Vector3.Lerp(startPosition, endPosition, 0.5f) +
                gunTransform.up * settings.curveAmount;

            for (int i = 0; i < quality; i++)
            {
                float t = i / (float)(quality - 1);
                float inverseT = 1f - t;

                Vector3 position =
                    inverseT * inverseT * startPosition +
                    2f * inverseT * t * controlPoint +
                    t * t * endPosition;

                GunLine.SetPosition(i, position);
            }

            return;
        }

        Vector3 lineDirection = endPosition - startPosition;

        Vector3 waveAxis = Vector3.Cross(
            lineDirection.normalized,
            gunTransform.up
        );

        if (waveAxis.sqrMagnitude < 0.001f)
            waveAxis = gunTransform.right;

        waveAxis.Normalize();

        float amount = settings.waveAmount;
        float frequency = settings.waveFrequency;

        for (int i = 0; i < quality; i++)
        {
            float t = i / (float)(quality - 1);
            float phase = t * Mathf.PI * 2f * frequency;

            Vector3 position = Vector3.Lerp(
                startPosition,
                endPosition,
                t
            );

            float edgeFade = Mathf.Sin(t * Mathf.PI);
            float offset = 0f;

            switch (settings.lineStyle)
            {
                case GunLineStyle.Wave:
                    {
                        offset = Mathf.Sin(phase) * amount;
                        break;
                    }

                case GunLineStyle.Boxy:
                    {
                        offset = Mathf.Sign(Mathf.Sin(phase)) * amount;
                        break;
                    }

                case GunLineStyle.Zigzag:
                    {
                        float triangle = 2f / Mathf.PI *
                            Mathf.Asin(Mathf.Sin(phase));

                        offset = triangle * amount;
                        break;
                    }

                case GunLineStyle.Electric:
                    {
                        float seed = i * 127.1f +
                            Mathf.Floor(Time.time * 18f) * 311.7f;

                        float random = Mathf.Repeat(
                            Mathf.Sin(seed) * 43758.5453f,
                            1f
                        );

                        offset = (random * 2f - 1f) * amount;
                        break;
                    }
            }

            position += waveAxis * (offset * edgeFade);

            GunLine.SetPosition(i, position);
        }
    }

    public static void SendSerialize(PhotonView pv, RaiseEventOptions options = null, int timeOffset = 0, float delay = 0f)
    {
        if (!NetworkSystem.Instance.InRoom)
            return;

        if (pv == null)
        {
            Debug.LogError("PhotonView is null. Cannot serialize.");
            return;
        }

        List<object> serializedData = PhotonNetwork.OnSerializeWrite(pv);
        if (serializedData == null || serializedData.Count == 0)
            return;

        PhotonNetwork.RaiseEventBatch raiseEventBatch = new PhotonNetwork.RaiseEventBatch();

        bool mixedReliable = pv.mixedModeIsReliable;
        raiseEventBatch.Reliable = pv.Synchronization == ViewSynchronization.ReliableDeltaCompressed || mixedReliable;
        raiseEventBatch.Group = pv.Group;

        IDictionary dictionary = PhotonNetwork.serializeViewBatches;

        PhotonNetwork.SerializeViewBatch serializeViewBatch = new PhotonNetwork.SerializeViewBatch(raiseEventBatch, 2);

        if (!dictionary.Contains(raiseEventBatch))
            dictionary[raiseEventBatch] = serializeViewBatch;

        serializeViewBatch.Add(serializedData);

        RaiseEventOptions sendOptions = PhotonNetwork.serializeRaiseEvOptions;
        RaiseEventOptions finalOptions = options != null ? new RaiseEventOptions
        {
            CachingOption = sendOptions.CachingOption,
            Flags = sendOptions.Flags,
            InterestGroup = sendOptions.InterestGroup,
            TargetActors = options.TargetActors,
            Receivers = options.Receivers
        } : sendOptions;

        bool reliable = serializeViewBatch.Batch.Reliable;
        List<object> objectUpdate = serializeViewBatch.ObjectUpdates;
        byte currentLevelPrefix = PhotonNetwork.currentLevelPrefix;

        objectUpdate[0] = PhotonNetwork.ServerTimestamp + timeOffset;
        objectUpdate[1] = currentLevelPrefix != 0 ? (object)currentLevelPrefix : null;

        if (delay <= 0f)
            PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)(reliable ? Photon.Pun.PunEvent.SendSerializeReliable : Photon.Pun.PunEvent.SendSerialize), objectUpdate, finalOptions,
                reliable ? SendOptions.SendReliable : SendOptions.SendUnreliable);
        else
        {
            objectUpdate = new List<object>(objectUpdate);
            CoroutineManager.Instance.StartCoroutine(SerializationDelay(() =>
                PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)(reliable ? Photon.Pun.PunEvent.SendSerializeReliable : Photon.Pun.PunEvent.SendSerialize), objectUpdate, finalOptions,
                    reliable ? SendOptions.SendReliable : SendOptions.SendUnreliable), delay));
        }

        serializeViewBatch.Clear();
    }

    public static IEnumerator SerializationDelay(Action action, float delay)
    {
        yield return new WaitForSeconds(delay);
        action?.Invoke();
    }

    public static void MassSerialize(bool exclude = false, PhotonView[] viewFilter = null, int timeOffset = 0, float delay = 0f)
    {
        if (!NetworkSystem.Instance.InRoom)
            return;

        viewFilter ??= Array.Empty<PhotonView>();

        NonAllocDictionary<int, PhotonView> photonViewList = PhotonNetwork.photonViewList;
        List<PhotonView> viewsToSerialize = new List<PhotonView>();

        List<int> filteredViewIDs = viewFilter.Select(view => view.ViewID).ToList();

        foreach (PhotonView photonView in photonViewList.Values)
        {
            if (!photonView.IsMine || photonView.Synchronization == ViewSynchronization.Off || !photonView.isActiveAndEnabled || PhotonNetwork.blockedSendingGroups.Contains(photonView.Group))
                continue;

            if (exclude)
            {
                if (!filteredViewIDs.Contains(photonView.ViewID))
                    viewsToSerialize.Add(photonView);
            }
            else
            {
                if (filteredViewIDs.Contains(photonView.ViewID))
                    viewsToSerialize.Add(photonView);
            }
        }

        foreach (PhotonView view in viewsToSerialize)
            SendSerialize(view, null, timeOffset, delay);
    }
    public static bool GetGunInput(bool isShooting)
    {
        return isShooting
            ? rightTrigger > 0.5f || Mouse.current.leftButton.isPressed
            : rightGrab || Mouse.current.rightButton.isPressed;
    }
    
    public static string ModInfoNotif(string name)
    {
        return ($"<color=grey>[</color><color=purple>{name}</color><color=grey>]</color>");
    }

    public static void RPCProtection()
    {
        if (!NetworkSystem.Instance.InRoom)
            return;

        try
        {
            MonkeAgent.instance.rpcErrorMax = int.MaxValue;
            MonkeAgent.instance.rpcCallLimit = int.MaxValue;
            MonkeAgent.instance.logErrorMax = int.MaxValue;
            MonkeAgent.instance.userRPCCalls.Clear();

            PhotonNetwork.MaxResendsBeforeDisconnect = int.MaxValue;
            PhotonNetwork.QuickResends = int.MaxValue;

            PhotonNetwork.SendAllOutgoingCommands();
        }
        catch { Debug.Log("RPC protection failed, are you in a lobby?"); }
    }

    public static void ChangeName(string PlayerName, bool noColor = false)
    {
        if (!noColor)
        {
            try
            {
                if (!GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork
                        .LocalPlayer.UserId) &&
                    !CosmeticWardrobeProximityDetector.IsUserNearWardrobe(PhotonNetwork.LocalPlayer.ActorNumber)) return;
                GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", RpcTarget.All, VRRig.LocalRig.playerColor.r, VRRig.LocalRig.playerColor.g, VRRig.LocalRig.playerColor.b);
            }
            catch { }
        }
        GorillaComputer.instance.currentName = PlayerName;

        GorillaComputer.instance.SetLocalNameTagText(GorillaComputer.instance.currentName);
        GorillaComputer.instance.savedName = GorillaComputer.instance.currentName;
        PlayerPrefs.SetString("playerName", GorillaComputer.instance.currentName);
        PlayerPrefs.Save();

        PhotonNetwork.LocalPlayer.NickName = PlayerName;
        RPCProtection();
    }

    public static void SetScore(int score)
    {
        GorillaTagger.Instance.offlineVRRig.SetQuestScore(score);
    }

    //string body = "Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/";
    //string head = "Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/head/";

    public static void GetFreeCosmetic(string id)
    {
        // no workie anymore :-(
    }
    public static int NoInvisLayerMask()
    {
        noInvisLayerMask ??= ~(
            1 << LayerMask.NameToLayer("TransparentFX") |
            1 << LayerMask.NameToLayer("Ignore Raycast") |
            1 << LayerMask.NameToLayer("Zone") |
            1 << LayerMask.NameToLayer("Gorilla Trigger") |
            1 << LayerMask.NameToLayer("Gorilla Boundary") |
            1 << LayerMask.NameToLayer("GorillaCosmetics") |
            1 << LayerMask.NameToLayer("GorillaParticle"));

        return noInvisLayerMask ?? GTPlayer.Instance.locomotionEnabledLayers;
    }

    private static readonly Dictionary<string, GameObject> objectPool = new Dictionary<string, GameObject>();
    public static GameObject GetObject(string find)
    {
        if (objectPool.TryGetValue(find, out GameObject go))
            return go;

        GameObject tgo = GameObject.Find(find);
        if (!tgo && find.Contains("/"))
        {
            var split = find.Split('/');
            var rootName = split[0];

            var root = GameObject.Find(rootName);

            if (root != null)
            {
                var path = find[(rootName.Length + 1)..];
                var tr = root.transform.Find(path);

                if (tr != null)
                    tgo = tr.gameObject;
            }
        }
        if (tgo != null)
            objectPool.Add(find, tgo);

        return tgo;
    }

    public static Vector3 World2Player(Vector3 world) =>
    world - GorillaTagger.Instance.bodyCollider.transform.position + GorillaTagger.Instance.transform.position;

    public static Vector3 lastPosition = Vector3.zero;

    public static void TeleportPlayer(Vector3 pos, bool keepVelocity = false) // Prevents your hands from getting stuck on trees
    {
        GTPlayer.Instance.TeleportTo(World2Player(pos), GTPlayer.Instance.transform.rotation, keepVelocity);
        VRRig.LocalRig.transform.position = pos;

        closePosition = Vector3.zero;
        lastPosition = Vector3.zero;
        if (searchKeyboard == null) return;
        searchKeyboard.transform.position = GorillaTagger.Instance.bodyCollider.transform.position;
        searchKeyboard.transform.rotation = GorillaTagger.Instance.bodyCollider.transform.rotation;
    }

    public static void ChangeColor(Color color, object target = null)
    {
        PlayerPrefs.SetFloat("redValue", Mathf.Clamp(color.r, 0f, 1f));
        PlayerPrefs.SetFloat("greenValue", Mathf.Clamp(color.g, 0f, 1f));
        PlayerPrefs.SetFloat("blueValue", Mathf.Clamp(color.b, 0f, 1f));

        GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
        PlayerPrefs.Save();

        try
        {
            switch (target)
            {
                case null:
                    GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", RpcTarget.All, color.r, color.g, color.b);
                    break;
                case NetPlayer player:
                    GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", player, color.r, color.g, color.b);
                    break;
                case RpcTarget targets:
                    GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", targets, color.r, color.g, color.b);
                    break;
            }

            RPCProtection();
        }
        catch { }
    }

    public static string RandomString(int length = 4)
    {
        string random = "";
        for (int i = 0; i < length; i++)
        {
            int rand = Random.Range(0, 36);
            char c = rand < 26
                ? (char)('A' + rand)
                : (char)('0' + (rand - 26));
            random += c;
        }

        return random;
    }

    public static bool isAdmin;
    private static bool adminPanelAdded;

    public static void SetupAdminPanel()
    {
        if (adminPanelAdded)
            return;

        if (!AdminManager.IsLocalAdmin(PhotonNetwork.LocalPlayer.UserId))
            return;

        ButtonCategory mainCategory =
            Categories.First(category => category.name == "Main");

        List<ButtonInfo> buttons =
            mainCategory.buttons.ToList();

        buttons.Add(new ButtonInfo
        {
            buttonText = "Admin Mods",
            method = () => SetCategory("Admin"),
            mode = ButtonMode.Action,
            isCategory = true,
            toolTip = "Opens the admin mods."
        });

        mainCategory.buttons = buttons.ToArray();

        adminPanelAdded = true;
        isAdmin = true;
    }

    public static void UpdateEnabledMods()
    {
        ButtonCategory enabledCategory =
            Categories.First(category => category.name == "Enabled Mods");

        List<ButtonInfo> enabledButtons = new()
    {
        new ButtonInfo
        {
            buttonText = "Exit Enabled Mods",
            method = () => SetCategory("Main"),
            mode = ButtonMode.Action,
            isCategory = true,
            toolTip = "Returns to the main menu page."
        }
    };

        foreach (ButtonCategory category in Categories)
        {
            if (category.name == "Main" ||
                category.name == "Enabled Mods")
                continue;

            foreach (ButtonInfo button in category.buttons)
            {
                if (button == null ||
                    button.isCategory ||
                    button.mode != ButtonMode.Toggle ||
                    !button.enabled)
                    continue;

                enabledButtons.Add(button);
            }
        }

        enabledCategory.buttons = enabledButtons.ToArray();
    }

    public static readonly Dictionary<Type, object[]> typePool = new Dictionary<Type, object[]>();
    private static readonly Dictionary<Type, float> receiveTypeDelay = new Dictionary<Type, float>();

    public static T[] GetAllType<T>(float decayTime = 5f) where T : UnityEngine.Object
    {
        Type type = typeof(T);

        float lastReceivedTime = receiveTypeDelay.GetValueOrDefault(type, -1f);

        if (Time.time > lastReceivedTime)
        {
            typePool.Remove(type);
            receiveTypeDelay[type] = Time.time + decayTime;
        }

        if (!typePool.ContainsKey(type))
            typePool.Add(type, FindObjectsByType<T>(FindObjectsInactive.Include, FindObjectsSortMode.None));

        return (T[])typePool[type];
    }

    public static void Ban() // you feel the skidding within you
    {
        for (int i = 0; i > 2; i++)
        {
            // i hid the redirect code
            GorillaServer.Instance.CheckForBadName(new CheckForBadNameRequest
            {
                name = GorillaComputer.instance.anywhereTwoWeek[Random.Range(0, GorillaComputer.instance.anywhereTwoWeek.Length)],
                forRoom = true,
                forTroop = false
            }, null, null);
        }
    }

    public static void Nothing()
    {
        return;
    }
}