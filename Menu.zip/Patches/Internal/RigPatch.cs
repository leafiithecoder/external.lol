﻿using HarmonyLib;

namespace externallol.Patches.Internal
{
    public class RigPatches
    {
        [HarmonyPatch(typeof(VRRig), nameof(VRRig.OnDisable))]
        public class OnDisable
        {
            public static bool Prefix(VRRig __instance)
            {
                return __instance != null && !__instance.isLocal;
            }
        }

        [HarmonyPatch(typeof(VRRig), nameof(VRRig.Awake))]
        public class Awake
        {
            public static bool Prefix(VRRig __instance)
            {
                return __instance?.gameObject != null &&
                       __instance.gameObject.name != "Local Gorilla Player(Clone)";
            }
        }

        [HarmonyPatch(typeof(VRRig), nameof(VRRig.PostTick))]
        public class PostTick
        {
            public static bool Prefix(VRRig __instance)
            {
                return __instance != null &&
                       (!__instance.isLocal || __instance.enabled);
            }
        }
    }
}